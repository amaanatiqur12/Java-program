import java.util.*;
public class day45{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		String c=input.next();
		char[] d = c.toCharArray();
		char temp;
		for(int i=c.length();i>c.length()-b;i--)
		{
			for(int j=c.length()-1;j>=1;j--)
			{
				if(d[j]>d[j-1])
				{
					temp=d[j];
					d[j]=d[j-1];
					d[j-1]=temp;
					j--;
				}
			}
		}
		StringBuilder g=new StringBuilder();
		g.append(d);
		System.out.println(g);
	}
}