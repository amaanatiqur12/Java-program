import java.util.*;
class day80 {
    public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		int n=input.nextInt();
        int count=0;
        for(int j=n-1;j>=-1;j--)//j=3  j=2
        {
            int k=j-2;//k=1   
            if(k<-1)   
            {
                break;
            }
			count =count +1;
			for(int y=k;y>=-1;y=y-2)
			{
				for(int z=y;z>=-1;)// z=1 z=-1  
				{
					z=z-2;
					if(z>=-1)  // z=1
					{
						count=count+1;
						z++;					//count=1 count =2
					}
				//z++;
				}
			}
        }
        System.out.println(count+1);
    }
}