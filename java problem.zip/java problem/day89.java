import java.util.*;
public class day89{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		input.nextLine();
		for(int i=0;i<a;i++)
		{
			String[] b=input.nextLine().split(" ");
			System.out.println(b[0]+" "+b[1]+" "+(int)Math.sqrt(Math.pow(Integer.parseInt(b[0]),2)+Math.pow(Integer.parseInt(b[1]),2)));
		}
	}
}