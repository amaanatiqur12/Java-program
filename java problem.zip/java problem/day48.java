import java.util.*;
public class day48{
	public static void main(String[]args)
	{
		Scanner input=new Scanner(System.in);
		int b=input.nextInt();
		String a=input.next();
		int o=0,p=0;
		for(int i=0;i<=a.length()-1;i++)
		{
			if(a.charAt(i)=='A')
			{
				o++;
			}
			else{
				p++;
			}
		}
		if(o>p)
			System.out.println("Anton");
		else if(o<p)
			System.out.println("Danik");
		else
			System.out.println("Friendship");
		
	}
}