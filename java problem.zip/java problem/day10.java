import java.util.*;
import java.util.InputMismatchException;
public class day10{
	public static void main(String[] args)
	{
		int z=0;
		int p=0;
		String s;
		boolean correct=false;
		Scanner i=new Scanner(System.in);
		while(!correct)
		{
			try
			{
				 p=i.nextInt();
				 Exception e=new Exception("");
				while(p<0)
				{
					System.out.print("Please Enter only positive Integer:");
					p=i.nextInt();
				}
				correct=true;
			}
			catch(Exception e)
			{
				System.out.print("Input error; Reenter:");
				i.next();   
			}
			
		}	
			if(p%2!=0)
			{
			
				for(int q=1;q<=p-1;q=q+2)
				{
					z=z+2;
				}
			}
			else{
			
				for(int q=2;q<=p-1;q=q+2)
				{
					z=z+1;
				}
			}
			System.out.print(z);
		
	}
}