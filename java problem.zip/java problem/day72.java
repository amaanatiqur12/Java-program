import java.util.*;
public class day72{
	public static void main(String[]aargs)
	{
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int[] b=new int[a];
		int sum=0;
		for(int i=0;i<a;i++)
		{
			b[i]=input.nextInt();
			sum+=b[i];
		}
		if(sum>0)
			System.out.println("HARD");
		else
			System.out.println("EASY");
	}
}