import java.util.*;
public class day79{
	public static void main(String[]args){
		Scanner input= new Scanner(System.in);
		String a=input.next();
		Solution(a,"",0,0);
	}
	public static void Solution(String pattern,String form,int count,int pos)
	{
		if(pos==pattern.length())
		{
			//System.out.println("1");
			if(count==0)
			{
				System.out.println(form);
			}	
			else if(pos==pattern.length())
			{
				System.out.println(form+count);
			}
			
			return; 
		
		}
		
		//System.out.println(form);
		if(count>0)
		{
			//System.out.println(form+count+pattern.charAt(pos)+"sddas");
			Solution( pattern ,form+count+pattern.charAt(pos) , 0 ,pos+1);
		}
		else
			Solution( pattern ,form+pattern.charAt(pos), 0 ,pos+1);
		
		
		Solution( pattern ,form, count+1 ,pos+1);
	}
}