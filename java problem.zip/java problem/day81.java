import java.util.*;
public class day81{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b1=input.nextInt();
		int b2=input.nextInt();
		int c1=input.nextInt();
		int c2=input.nextInt();
		int k=0;
		int money=0;
		if(b2/b1>c2/c1)
		{
			int d=a/c1;
			k=c1*d;
			money=money+c2*d;
			while(k!=a)
			{
				k=k-c1+b1;
				money=money-c2+b2;
			}	
		}
		else
		{
			int d=a/b1;
			k=b1*d;
			money=money+b2*d;
			while(k!=a)
			{
				k=k-b1+c1;
				money=money-b2+c2;
			}
		}
		System.out.println(money);
	}
}