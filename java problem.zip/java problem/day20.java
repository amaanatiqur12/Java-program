import java.util.*;
public class day20{
	public static void main(String[] args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		int b=0,k=9;
		
		while(b<=a.length()-1)
		{
			int d=a.charAt(b);
			
			if(b!=0&&d>=97)
			{
				k=1;
				break;
			}
			b++;
		}
		if(k!=1&&a.length()!=1)
		{
			char first_char=a.charAt(0);
			int w=first_char;
			String first=Character.toString(first_char);
			String g=charRemoveAt(a, 0);
			g=g.toLowerCase();
			if(w<=90)
			{
				first=first.toLowerCase();
			}
			else
			{
				first=first.toUpperCase();
			}
			
			a=first+g;
		}
		if(a.length()==1)
		{
			char first_char=a.charAt(0);
			int w=first_char;
			if(w<=90)
			{
				a=a.toLowerCase();
			}
			else
			{
				a=a.toUpperCase();
			}
			
		}
		System.out.print(a);
	}
	 public static String charRemoveAt(String str, int p) {  
              return str.substring(0, p) + str.substring(p + 1);  
     }  
}