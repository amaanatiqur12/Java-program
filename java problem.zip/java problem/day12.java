import java.util.*;
public class day12{
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		int n=input.nextInt();
		int k=input.nextInt();
		if(n>=k)
		{
			int i=0;
			int a[]=new int[n];
			while(i<n)
			{
				a[i]=input.nextInt();
				i++;
			}
			i=k-1;
			
			if(a[i]!=0)
			{
			while(i+1<=n-1)
			{
				if(a[i]==a[i+1])
				{
					
					i++;
					
				}
				else
				{
				
					break;
				}
			}
			i=i+1;
			System.out.print(i);

			}
			else
			{
				
				i--;
				if(i>=0)
				{
				while(a[i]==0)
				{
					
					i--;
					
					if(i<0)
					{
						
						break;
					}
				}
				}
				if(i<0)
				{
					System.out.print("0");
				}
				else
				{
					i=i+1;
					System.out.print(i);
				}
			}
		}
	}
}