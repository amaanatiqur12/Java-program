import java.util.*;
public class day28{
	public static void main(String[] args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		char b;
		int c,v=0;
		String s;
		b=a.charAt(0);
		s=Character.toString(b);
		s=s.toUpperCase();
	    a=removeString(a,0);
		a=s+a;
		System.out.println(a);
	}
	public static String removeString(String hh,int bb)
	{
		return hh.substring(0,bb)+hh.substring(bb+1);
	}
}