public class day6{
	public static void main(String[] args)
	{
		String text="jfdksd";
		char ch = (char)(((int)text.charAt(0) + 5 - 97)%26+97);
		System.out.print(ch);
	}
}
 //The ASCII value of lowercase alphabets are from 97 to 122. And, the ASCII value of uppercase alphabets are from 65 to 90. 