import java.util.*;
public class day82{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		
		//int a=input.nextInt();
		//input.nextLine(); 
		String str = input.nextLine();
		
        String[] arrOfStr = str.split(" ");
		//System.out.println(Arrays.toString(arrOfStr));
		int[] b=new int[arrOfStr.length];
		for(int i=0;i<arrOfStr.length;i++)
		{
			b[i]=Integer.parseInt(arrOfStr[i]);
		}
		
		for(int i=0;i<arrOfStr.length;i++)
		{
			for(int j=0;j<arrOfStr.length-i-1;j++)
			{
				if(b[j]>b[j+1])
				{
					int temp=b[j];
					b[j]=b[j+1];
					b[j+1]=temp;
				}
			}
		}
		for(int i=0;i<arrOfStr.length;i++)
		{
			System.out.print(b[i]+" ");
		}
	}
}