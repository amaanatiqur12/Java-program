import java.util.*;
public class Selected{
	public static void main(String[]args){
		int[] a={-7,4,6,7,55,1,2,-9};
		int largest;
		for(int i=a.length-1;i>0;i--)
		{
			largest=0;
			for(int j=1;j<=i;j++)
			{
				if(a[largest]<a[j])
				{
					largest=j;
				}
			}
			swap(a,largest,i);
		}
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
	public static void swap(int[] n,int ii,int jj)
	{
		int temp=n[ii];
		n[ii]=n[jj];
		n[jj]=temp;
	}
}

/**import java.util.*;
public class Selected{
	public static void main(String[]args){
		int[] a={-5,4,3,6,-7,78,656,432,5,62};
		int f,g;
		for(int i=a.length-1;i>0;i--)
		{
			f=a[0];
			g=0;
			for(int j=1;j<=i;j++)
			{
			    if(f<a[j])
				{
					g=j;
					f=a[g];
				}
			}
			swap(a,g,i);
		}
		for(int i=0;i < a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
	public static void swap(int[] n,int ii,int jj)
	{		
		int temp = n[ii];
		n[ii] = n[jj];
		n[jj] = temp;
	}
}**/