import java.util.*;
public class day59{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int sum=0;
		
		int c=1;
		int g=a;
		
		for(int i=0;i<=a-1;i++)
		{
			int k=g-i;
			while(k>0)
			{
				sum+=c;
				k--;
			}
			if(a!=i+1)
			{
				c++;
				sum++;
				g=a-1;
			}
			if(c==a)
			{
				break;
			}
			
		}
		System.out.println(sum);
	}
}