import java.util.*;
public class day96{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		if(a>=30&&a<=50)
			System.out.println("D");
		else if(a>=51&&a<=60)
			System.out.println("C");
		else if(a>=61&&a<=80)
			System.out.println("B");
		else if(a>=80&&a<=100)
			System.out.println("A");
	}
}