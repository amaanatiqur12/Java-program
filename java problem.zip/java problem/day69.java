import java.util.*;
public class day69{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int[] a={1,1,1,0,0,0};
		int count=0;
		for(int i=0;i<a.length;i++)
		{
			int b=a[i];
			for(int j=0;j<count;j++)
			{
				if(b==0)
				{
					b=1;
				}
				else
				{
					b=0;
				}
			}
			
			if(b==1)
			{
				
				count+=1;
			}
		}
		System.out.println(count);
	}
}