import java.util.*;
public class day97{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String[] a=input.nextLine().split(" ");
		int c=input.nextInt();
		int[] b=new int[a.length];
		for(int i=0;i<a.length;i++)
			b[i]=Integer.parseInt(a[i]);
		int sum=0;
		for(int i=0;i<a.length;i++)
			sum+=b[i]%c;
		System.out.println(sum);
	}
}