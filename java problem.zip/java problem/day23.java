import java.util.*;
import java.util.Arrays;
public class day23{
	public static void main(String [] args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		Integer b[]=new Integer[a];
		for(int i=0;i<=b.length-1;i++)
		{
			b[i]=input.nextInt();
		}
		Arrays.sort(b, Collections.reverseOrder());
		int w=0,q=0,r=0,m=a;
		while(w<=m-1)
		{
			q=b[w];
			
			while(q<4&&m-1!=w)
			{
				
				q=q+b[m-1];
				
				if(q<=4)
				{
					m--;
				}
				
			}
			
				
			
			r++;
			w++;
		}
		System.out.println(r);
	}
}