import java.util.*;
public class day61{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int c=a/2+a%2;
		int g=0;
		while(g!=a/2&&c%b!=0)
		{
			g++;
			c++;
			if(c%b==0)
			{
				break;
			}
		}
		if(c%b==0)
			System.out.println(c);
		else
			System.out.println("-1");
	}
}