import java.util.*;
public class day102{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		ArrayList<Integer> a=new ArrayList<>();
		String[] b=input.next().split("");
		for(int i=0;i<b.length;i++)
		{
			
		}
	}
}