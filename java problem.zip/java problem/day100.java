import java.util.*;
public class day100{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String g=input.nextLine();
		String[] a=g.split("");
		for(int i=0;i<a.length-1;i++)
		{
			int w=g.length()-g.replaceAll(a[i],"").length();
			if(w==1)
			{
				System.out.println(a[i]);
				break;
			}
		}
	}
}