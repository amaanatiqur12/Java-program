import java.util.*;
public class day40{
	public static void main(String [] args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b[]=new int[a];
		for(int i=0;i<=a-1;i++)
		{
			b[i]=input.nextInt();
		}
		int c=0,d=0,e=0,f=0;
		for(int i=0;i<=a-1;i++)
		{
			if(b[i]==1)
			{
				c++;
			}
			else if(b[i]==2)
			{
				d++;
			}
			else if(b[i]==3)
			{
				e++;
			}
			else if(b[i]==4)
			{
				f++;
			}
		}
		int g=0;
		g=f;
		int u=0;
		if(c==e)
		{
			g=g+c;
		}
		else if(c>e)
		{
			u=c-e;
			c=c-e;
			g=g+u;
			
			u=c%2;
			int z=c/2;
			if(z==d)
			{
				g=g+z;
			}
			else if(z>d)
			{
				int o=z-
			}
			g=g+
			
		}
		else if(c<e)
		{
			u=e-c;
			e=e-c
			g=g+u;
		}
	}
}