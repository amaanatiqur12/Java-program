import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

class Result {

    public static String encryption(String s) {
        String[] y = s.split(" ");	
		String joined_str = String.join("", y);
		
		int b;
        double tt=Math.sqrt(joined_str.length());
        int a=(int)tt;
        if(tt==a)
        {
            a=(int)tt;
            b=a;
        
        }
        else
        {
            a=(int)tt;
            b=a+1;
            System.out.println(a+"<=>"+b);
        }
        
		
		//System.out.println(b);
		
		ArrayList<String> o=new ArrayList();
		for(int i=0;i<joined_str.length();)
		{
			if(i+b<joined_str.length())
			{
				o.add(SubString1(joined_str,i,i+b));
				i=i+b;
			}
			else
			{
				int v=joined_str.length()-i;
				o.add(SubString1(joined_str,i,i+v));
				break;
			}
		}
		String[] r=new String[o.size()];
		for(int i=0;i<r.length;i++)
		{
			r[i]=o.get(i);
		}
		/**for(int i=0;i<r.length;i++)
		{
			System.out.println(r[i]);
		}**/
		String[] w=new String[b];
		String d,ll;
		for(int i=0;i<r.length;i++)
		{
			d=r[i];
			if(w[0]==null)
			{
				for(int j=0;j<d.length();j++)
				{
					w[j]=String.valueOf(d.charAt(j));
				}
			}
			else
			{
				for(int j=0;j<d.length();j++)
				{
					ll=w[j];
					w[j]=ll+String.valueOf(d.charAt(j));
				}
			}
		}
		
		joined_str = String.join(" ", w);
		return joined_str;
		
    }
	public static String SubString1(String r,int y,int k)
	{
		return r.substring(y,k);
	}	
}

public class Encryption{
    public static void main(String[] args) throws IOException {
      
		Scanner input = new Scanner(System.in);

        String s = input.nextLine();
		
        Result y = new Result();
		
		System.out.println(y.encryption(s));
    }
}
