import java.util.*;
public class day87{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String[] a=input.next().split(",");
		int[] b=new int[a.length];
		HashMap<Integer,Integer> c=new HashMap<>();
		for(int i=0;i<a.length;i++)
		{
			b[i]=Integer.parseInt(a[i]);
			c.put(b[i],c.getOrDefault(b[i],0)+1);
		}
		for(int key : c.keySet())
		{
			System.out.print(key+" ");
		}
		/**for(int i=0;i<b.length;i++)
		{
			if(c.get(b[i])==null)
			{
				c.put(b[i],1);
			}
			else
			{
				c.put(b[i],c.get(b[i])+1);
			}
			
		}**/
	}
}