import java.util.*;
public class day84{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		String b=input.next();
		String k=SubString(b,a);
		int zeros = k.length() - k.replaceAll("0", "").length();
		int ones = k.length() - k.replaceAll("1", "").length();
		if(ones!=0)
			System.out.println(ones);
		else
			System.out.println(zeros);
	}
	public static String SubString(String c,int d)
	{
		return c.substring(1,d-1);
	}
}