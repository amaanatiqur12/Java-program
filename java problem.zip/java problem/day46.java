import java.util.*;
public class day46{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		int u=0;
		int l=0,k=0;
		for(int i=0;i<=a.length()-1;i++)
		{
			if(a.charAt(i)!='4'&&a.charAt(i)!='7')
			{
				u=1;
				break;
			}
			if(a.charAt(i)=='4')
			{
				l=1;
			}
			if(a.charAt(i)=='7')
			{
				k=1;
			}
		}
		if(l==1&&k==1&&u==0)
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}