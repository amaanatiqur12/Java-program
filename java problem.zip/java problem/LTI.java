/**import java.util.*;
public class LTI{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);	
		char a=input.next().charAt(0);
		
		input.nextLine();
		
		String b=input.nextLine();
		//System.out.println(b);
		//input.nextLine();
		String[] c=b.split(String.valueOf(a));
		System.out.println(Arrays.toString(c));
		String w=String.join("",c);
		System.out.println(w);
		
		
		
	}
}**/
import java.util.*;
public class LTI{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int[] b=new int[a];
		for(int i=0;i<a;i++)
		{
			b[i]=input.nextInt();
		}
		System.out.println("-------------------------------------");
		int c=input.nextInt();
		int[] d=new int[c];
		for(int i=0;i<c;i++)
		{
			d[i]=input.nextInt();
		}
		HashMap<Integer,Integer> e=new HashMap();
		for(int i=0;i<a;i++)
		{
			if(e.containsKey(b[i]))
			{
				e.put(b[i],e.get(b[i])+1);
			}
			else
			{
				e.put(b[i],1);
			}
		}
		//System.out.println(e);
		ArrayList<Integer> p=new ArrayList();
		int o;
		for(int i=0;i<c;i++)
		{
			o=e.get(d[i]);
			for(int j=o-1;j>=0;j--)
			{
				p.add(d[i]);
			}
			e.remove(d[i]);
		}
		for(int i=0;i<c;i++)
		{
			o=e.get(d[i]);
			for(int j=o-1;j>=0;j--)
			{
				p.add(d[i]);
			}
			e.remove(d[i]);
		}
		for(int i=0;i<c;i++)
		{
			o=e.get(d[i]);
			for(int j=o-1;j>=0;j--)
			{
				p.add(d[i]);
			}
			e.remove(d[i]);
		}
		for(int i=0;i<p.size();i++)
		{
			System.out.println(p.get(i));
		}
		Set<String> keys = e.keySet();
		//print all the keys 
		for (String key : keys) {
			System.out.println(key);
		}
		//System.out.println(e);
		for (Integer i: m.keySet()) {
			System.out.println(m.get(i));
		}
	}
}