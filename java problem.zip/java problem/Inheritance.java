import java.util.*;
class dog
{
	public void walk()
	{
		System.out.println("Walk");
	}
	public void sleep()
	{
		System.out.println("Sleep");
	}
	public void eat()
	{
		System.out.println("Eat");
	}
}
class dog1 extends dog
{
	public void color()
	{
		System.out.println("Red");
	}
	public void size()
	{
		System.out.println("small");
	}
}
class dog2 extends dog
{
	public void color()
	{
		System.out.println("brown");
	}
	public void size()
	{
		System.out.println("medium");
	}
}
class dog3 extends dog
{
	public void color()
	{
		System.out.println("black");
	}
	public void size()
	{
		System.out.println("large");
	}
}
public class Inheritance{
	public static void main(String[] args){
		dog3 a=new dog3();
		a.color();
		a.sleep();
	}
}