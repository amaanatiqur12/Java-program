import java.util.*;
public class day95{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String[] a=input.nextLine().split(" ");
		HashMap<Integer,Integer> b=new HashMap<>(); 
		for(int i=0;i<a.length;i++)
			b.put(Integer.parseInt(a[i]),b.getOrDefault(Integer.parseInt(a[i]),0)+1);
		int l=0;
		for(int value:b.values())
			if(value>1)
				l=l+1;
		if(l>=1)
			System.out.println(l);
		else
			System.out.println(-1);
	}
}