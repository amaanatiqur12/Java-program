import java.util.*;
public class day63{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		String b=a.replaceAll("x+","");
		if(b.contains("T$")||b.contains("$T"))
			System.out.println("ALARM!");
		else
			System.out.println("SAFE!");	
		
		//System.out.println(c);
		/**int j=0;
		int k=0;
		int l=0;
		char c;
		
		for(int i=0;i<=b.length()-1;i++)
		{
			c=b.charAt(i);
			
			
			if(c=='T'||j==1)
			{
				if(c=='T'||c=='$')
				{
					j=1;
				}
				else
				{
					j=0;
				}
				
				if(c=='$')
				{
					k=1;
					
					break;
				}	
				
			}
			
			
			if(c=='$'||l==1)
			{
				if(c=='$'||c=='T')
				{
					l=1;
				}
				else
				{
					l=0;
				}
				
				
				if(c=='T')
				{
					k=1;
					
					break;
				}	
			}
			else
			{
				l=0;
			}
			if(k==1)
			{
				break;
			}
		}
		if(k==1)
		{
			System.out.println("ALARM!");
		}
		else
		{
			System.out.println("Safe!");
		}**/
	}
}