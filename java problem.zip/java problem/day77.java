import java.util.*;
public class day77{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String i=input.next();
		int k=0;
		int j1,j2,j3;
		for(int j=0;j<i.length();j++)
		{
			j1=j;
			if(j+1<i.length())
			{
				j2=j+1;
			}
			else
			{
				j2=j;
			}
			if(j+2<i.length())
			{
				j3=j+2;
			}
			else
			{
				j3=j;
			}
			if(i.charAt(j1)=='1'&&i.charAt(j2)=='4'&&i.charAt(j3)=='4')
			{
				j=j+2;
			}
			else if(i.charAt(j1)=='1'&&i.charAt(j2)=='4')
			{
				j=j+1;
			}
			else if(i.charAt(j)=='1')
			{
				continue;
			}
			else
			{
				k=1;
				System.out.println("NO");
				break;
			}
		}
		if(k==0)
		{
			System.out.println("YES");
		}
	}
}