import java.util.*;
public class day42{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		int o=0;
		for(int i=0;i<=a.length()-1;i++)
		{
			if(a.charAt(i)>96)
			{
				o++;
			}
		}
		
		if(o>=(float)a.length()/2)
		{
			System.out.println(a.toLowerCase());
		}
		else
		{
			System.out.println(a.toUpperCase());
		}
	}
}