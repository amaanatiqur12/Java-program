import java.util.*;
public class try1{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int e=input.nextInt();
		for(int i=1;i<=e;i++)
			System.out.println(fibo(i));
	}
	public static int fibo(int s)
	{
		if(s==1)
			return 0;
		else if(s==2)
			return 1;
		
		return fibo(s-2)+fibo(s-1);
	}
}