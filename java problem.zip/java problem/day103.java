import java.util.*;
public class day103{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int[] b=new int[9];
		while(a!=0)
		{
			while(a/2==0)
			{
				b[2]+=1;
				a=a/2;
			}
			while(a/3==0)
			{
				b[3]+=1;
				a=a/3;
			}
			if(a/5==0)
			{
				b[5]+=1;
				a=a/5;
			}
			if(a/7==0)
			{
				b[7]+=1;
				a=a/7;
			}
		}
		int two=0;
		int count2=0;
		int three=0;
		int five=0;
		int seven=0;
		if(b[2]-4>0)
		{
			while(b[2]-4>0)
			{
				b[2]=b[2]-4;
				count2*=1;
			}
			
		}
		if(b[2]>0)
		{
			two=b[2]*2;
		}
		
		int count3=0;
		if(b[3]-2>0)
		{
			while(b[3]-2>0)
			{
				b[3]=b[3]-2;
				count3*=1;
			}
		}
		if(b[3]>0)
		{
			three=b[3]*3;
		}
	    ArrayList<String> number=new ArrayList<>();
		if(count2>0)
		{
			while(count2>0)
			{
				number.add(8);
				--count2;
			}
		}
		if(two>0)
		{
			number.add(two);
		}
		if(count3>0)
		{
			while(count3>0)
			{
				number.add(9);
				--count3;
			}
		}
		if(three>0)
		{
			number.add(three);
		}
	}
}