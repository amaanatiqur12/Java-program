import java.util.*;
public class day33{
	public static void main(String[] args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b[]=new int[a];
		int c[]=new int[a];
		int d[]=new int[a];
		List e=new ArrayList();
		for(int i=0;i<=a-1;i++)
		{
			b[i]=input.nextInt();
			c[i]=input.nextInt();
			d[i]=input.nextInt();
		}
		int f=0;
		int g,h,k;
		while(f<=a-1)
		{
			if(b[f]>c[f])
			{
				g=b[f];
				h=c[f];
			}
			else{
				g=c[f];
				h=b[f];
			}
			k=d[f];
			int j=0;
			while(true)
			{
				h=h+g;
				j++;
				if(h>k)
				{
					e.add(j);
					break;
				}
				g=g+h;
				j++;
				if(g>k)
				{
					e.add(j);
					break;
				}
			}
			f++;
		}
		for(int i=0;i<=e.size()-1;i++)
		{
			System.out.println(e.get(i));
		}
	}	
}