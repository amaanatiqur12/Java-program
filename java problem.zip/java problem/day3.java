import java.util.*;
public class day3{
public static void main(String []args){
		String[] keywork={"break", "case", "continue", "default","defer", "else", "for","func", "goto","if","map", "range","return","struct","type","var"};
	Scanner a=new Scanner(System.in);
	String i=a.nextLine();
	int k=0;
	for(String value:keywork)
	{
		if(value.equals(i)){
			System.out.print(i+" is a keyword");
			k=1;
		}
		
				
	}
	if(k==0)
	{
			System.out.print(i+" is not a keyword");

	}	
}
}