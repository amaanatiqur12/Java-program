import java.util.*;
public class recusion{
	public static void main(String[]args){
		Scanner input=new  Scanner(System.in); 
		int i=input.nextInt();
		System.out.println(factorial(i));
	}
	public static int factorial(int k)
	{
		if(k==0||k==1)
			return 1;
		
		return k*factorial(k-1);
	}
}