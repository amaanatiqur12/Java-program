import java.util.*;
public class day90{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		ArrayList<ArrayList<Integer> > aList = new ArrayList<ArrayList<Integer> >();
		
	}
}