import java.util.*;
class bird
{
	public void sing(){
		System.out.println("sing sing sing");
	}
}
class crow extends bird
{
	
}
public class polymorphism{
	public static  void main(String[]args){
		crow y=new crow();
		y.sing();
	}
}