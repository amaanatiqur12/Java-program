import java.util.*;
public class day83{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int c=input.nextInt();
		List<Integer> a=new ArrayList<>();
		List<Integer> b=new ArrayList<>();
		for(int i=0;i<c;i++)
		{
			int d=input.nextInt();
			if(d%2==0)
			{
				a.add(d);
			}
			else
			{
				b.add(d);
			}
		}
		a.addAll(b);
		for(int i=0;i<c;i++)
		{
			System.out.println(a.get(i));
		}
	}
}