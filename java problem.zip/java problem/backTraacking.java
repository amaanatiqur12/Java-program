import java.util.*;

import java.io.*;

class myCode
{
    public static void main (String[] args) throws java.lang.Exception
    {
        Scanner input=new Scanner(System.in);
        String a=input.next();
        String[] b=a.split(",");
        int[] c=new int[b.length];
        for(int i=0;i<b.length;i++)
        {
            c[i]=Integer.parseInt(b[i]);
        }
        backTracking(c,0,new ArrayList<>(),new ArrayList<>(),0,0);
        System.out.println(ans);
    }
    static int max=Integer.MAX_VALUE;
    static String ans="";
    public static void backTracking(int[] c,int vetx,ArrayList<Integer> set1,ArrayList<Integer> set2,int sum1,int sum2)
    {
        if(vetx==c.length)
        {
            int diff=Math.abs(sum1-sum2);
            if(diff<max)
            {
                max=diff;
                if(sum1>sum2)
                {
                    ans=sum2+" "+sum1;
                }
                else
                {
                    ans=sum1+" "+sum2;
                }
                
            }
            return;
        }
        if(set1.size()<(c.length+1)/2)
        {
            set1.add(c[vetx]);
            
            
            backTracking(c,vetx+1,set1,set2,sum1+c[vetx],sum2);
            set1.remove(set1.size()-1);
        }
        if(set2.size()<(c.length+1)/2)
        {
            set2.add(c[vetx]);
      
            
            backTracking(c,vetx+1,set1,set2,sum1, sum2+c[vetx]);
            set2.remove(set2.size()-1);
        }
    }
}