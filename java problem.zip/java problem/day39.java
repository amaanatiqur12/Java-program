import java.io.*;
import java.util.*;
import java.math.*;
  
public class day39
{
    // Returns n-th Fibonacci number
    static BigInteger fib(int n)
    {
        BigInteger a = BigInteger.valueOf(0);
        BigInteger b = BigInteger.valueOf(1);
        BigInteger c = BigInteger.valueOf(1);
        for (int j=2 ; j<=n ; j++)
        {
            c =  a.add(b);
            a = b;
            b = c;
        }
  
        return (b);
    }
  
    public static void main(String[] args)
    {
		Scanner input=new Scanner(System.in);
        int n = input.nextInt();
        System.out.println("Fibonacci of " + n +
            "th term" + " " +"is" +" " + fib(n));
    }
}
/**import java.math.BigInteger;
import java.util.Scanner;
		
	
	
public class day39
{
	public static int N;
	
    // Returns Factorial of N
	
    static BigInteger factorial(int N)
    {
        // Initialize result
        BigInteger f = new BigInteger("1"); // Or BigInteger.ONE
  
        // Multiply f with 2, 3, ...N
		 if(N==1||N==2)
		{
			f=BigInteger.ONE;
		}
		else
		{
			BigInteger a=factorial(N-1);
			BigInteger b=factorial(N-2);
			f=a.add(b);
				
		}
            
		return f;
    }
  
    // Driver method
    public static void main(String args[])
    {
		int c=0;
       Scanner input=new Scanner(System.in);
	   do{
			N =input.nextInt();
			
			System.out.println(factorial(N));
			System.out.println("Enter the 1 to continue:");
			c=input.nextInt();
	   }while(c==1);
    }
}**/