import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class journeyToTheMoon {
    public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		int n = input.nextInt();

        int p = input.nextInt();

        List<List<Integer>> astronaut = new ArrayList<>();

        for (int i = 0; i < p; i++) {
           // String[] astronautRowTempItems = bufferedReader.readLine().replaceAll("\\s+$", "").split(" ");

            List<Integer> astronautRowItems = new ArrayList<>();

            for (int j = 0; j < 2; j++) {
                int astronautItem = input.nextInt();
                astronautRowItems.add(astronautItem);
            }

            astronaut.add(astronautRowItems);
        }
        ArrayList<Integer> number=new ArrayList<Integer>();
        for(int i=0;i<=n-1;i++)
        {
            number.add(i);
        }
        ArrayList<ArrayList<Integer> > aList = new ArrayList<ArrayList<Integer> >();
        
        int a=0;
        int b=0;
        int t=0;
        int u=0;
		int index1=0;
        int index2=0;
		int index=0;
        for(int i=0;i<astronaut.size();i++)
        {
            ArrayList<Integer> List=new ArrayList<Integer>();
            t=0;u=0;
            a=astronaut.get(i).get(0);
            b=astronaut.get(i).get(1);
            if(number.remove(new Integer(a)))
            {
                t=1;
            }
            if(number.remove(new Integer(b)))
            {
                u=1;
            }
            if(t==1&&u==1)
            {
                List.add(a);
                List.add(b);
                aList.add(List);
            }
            else if(t==1&&u==0)
            {
                
                for(int j=0;j<aList.size();j++)
                {
                   if(aList.get(j).contains(b))
                   {
                       index=j;
                       break;
                   } 
                }
                aList.get(index).add(a);
            }
            else if(t==0&&u==1)
            {
               
                for(int j=0;j<aList.size();j++)
                {
                   if(aList.get(j).contains(a))
                   {
                       index=j;
                       break;
                   } 
                }
                aList.get(index).add(b);
            }
            else if(t==0&&u==0)
            {
                
                for(int j=0;j<aList.size();j++)
                {
                   if(aList.get(j).contains(a))
                   {
                       index1=j;
                       break;
                   } 
                }
					for(int j=0;j<aList.size();j++)
					{
						if(aList.get(j).contains(b))
						{
						index2=j;
						break;
						} 
					}
					for(int j=0;j<aList.get(index2).size();j++)
					{
						
						aList.get(index1).add(aList.get(index2).get(j));
					}
					aList.get(index2).clear();
				}
            
		}
        
			int ways=0;
			long q=0;
			int o=0;
			for(int i=0;i<aList.size();i++)
			{
            
				for(int j=i+1;j<aList.size();j++)
				{
					q=q+aList.get(i).size()*aList.get(j).size();
				}
			}
       
			long k=number.size()-1;
			q=q+(k*(k+1))/2;
        
      
			for(int i=0;i<aList.size();i++)
			{
				q=q+aList.get(i).size()*number.size();
			}
		System.out.println(q);	
    }

}