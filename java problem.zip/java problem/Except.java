import java.util.*;
public class Except{

	public static void main(String[] args) {
		
		Scanner input=new Scanner(System.in);	
		int n=input.nextInt();
		int m=input.nextInt();
		int coins[]=new int[m];
		for(int i=0;i<=m-1;i++)
		{
			coins[i]=input.nextInt();
		}
		System.out.println("count=>"+ways(n,coins));
		
	}
	
	 public static int o=0;
    // Complete the ways function below.
    static int ways(int n, int[] coins) {
        if(n==0)
        {
            o++;
            return 0;
        }
        
        for(int i=0;i<coins.length-1;i++)
        {
            if(n-coins[i]>=0)
			{
            int k=ways(n-coins[i],coins);    
			}
        }
        return o;
    }
}
/**
import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class Solution {
    
    public static int o=0;
    ArrayList g=new ArrayList();
   ArrayList<ArrayList<Integer> > x = new ArrayList<ArrayList<Integer> >();
    // Complete the ways function below.
    static int ways(int n, int[] coins) {
        if(n==0)
        {
            o++;
            return 0;
        }
        
        for(int i=0;i<coins.length-1;i++)
        {
            if(n-coins[i]>=0)
            {
                int k=ways(n-coins[i],coins);    
            }
            else
            {
                
            }
        }
        return o;
    }

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        String[] nm = scanner.nextLine().split(" ");

        int n = Integer.parseInt(nm[0]);

        int m = Integer.parseInt(nm[1]);

        int[] coins = new int[m];

        String[] coinsItems = scanner.nextLine().split(" ");
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        for (int i = 0; i < m; i++) {
            int coinsItem = Integer.parseInt(coinsItems[i]);
            coins[i] = coinsItem;
        }

        int res = ways(n, coins);

        bufferedWriter.write(String.valueOf(res));
        bufferedWriter.newLine();

        bufferedWriter.close();

        scanner.close();
    }
}**/
