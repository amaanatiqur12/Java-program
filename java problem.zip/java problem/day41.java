import java.util.*;
public class day41{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b[]=new int[a];
		HashMap<Integer,Integer> g=new HashMap();
		for(int i=0;i<=a-1;i++)
		{
			b[i]=input.nextInt();
			if(g.get(b[i])!=null)
			{
				g.put(b[i],g.get(b[i])+1);
			}
			else
			{
				g.put(b[i],1);
			}
		}
		
		
		int c=input.nextInt();
		int d[]=new int[c];
	
		int e[]=new int[c];
		for(int i=0;i<=c-1;i++)
		{
			d[i]=input.nextInt();
			TreeMap<Integer,Integer> tm=new  TreeMap<Integer,Integer> (g);
			Iterator<Integer> o=tm.keySet().iterator();
			while(o.hasNext())
			{
				int l=o.next();
				if(l<=d[i])
				{
					e[i]=e[i]+g.get(l);
				}
				else
				{
					break;
				}
				
			}
			
		}	
		for(int i=0;i<=e.length-1;i++)
		{
			System.out.println(e[i]);
		}
	}
}