import java.util.*;
public class day17{
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b[]=new int[a];
		int c[]=new int[a];
		int d[]=new int[a];
		int f=0,w=0,y=0,z=0;
		for(int h=0;h<=a-1;h++)
		{
			b[h]=input.nextInt();
			c[h]=input.nextInt();
			d[h]=input.nextInt();
		}
		while(f<=a-1)
		{
		
			w=w+b[f];
			y=y+c[f];
			z=z+d[f];
			
			f++;
		}
		if(w==0&&y==0&&z==0)
		{
			System.out.println("YES");
		}
		else
		{
			System.out.println("NO");
		}
	}
}