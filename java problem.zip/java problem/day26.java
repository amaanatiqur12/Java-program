import java.util.*;
public class day26{
	public static void main(String [] args)
	{
		Scanner input=new Scanner(System.in);
		String a=input.next();
		String b=input.next();
		a=a.toLowerCase();
		b=b.toLowerCase();
		int o=0;
		for(int i=0;i<=a.length()-1;i++)
		{
			if(a.charAt(i)<b.charAt(i))
			{
				o=-1;
				break;
			}
			else if(a.charAt(i)>b.charAt(i))
			{
				o=1;
				break;
			}
		}
		System.out.println(o);
	}
}