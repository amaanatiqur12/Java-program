
import java.util.*;
public class fibo_recussion{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		
		int[] v=new int[2147483];
		int j=0;
		do
		{
			int a=input.nextInt(); 
			for(int i=0;i<a;i++)
			{
				System.out.println(fibbo(i,v));
			}
			System.out.println("Enter -1 to exist or enter 0:");
			j=input.nextInt();
		}while(j==0);
	}
	
	public static int fibbo(int o,int[] e)
	{
		if(e[o]!=0)
		{
			System.out.println("aeae");
			return e[o];
		}
		else if(o==0)
		{
			e[0]=0;
			return 0;
		}
		else if(o==1)
		{
			e[1]=1;
			return 1;
		}
		int s=fibbo(o-2,e)+fibbo(o-1,e);
		e[o]=s;
		return s;
	}
}