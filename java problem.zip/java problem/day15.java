import java.util.*;
public class day15{
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		String a=input.next();
		int i=0,c=0;
		char b,v='e';
		while(i<=a.length()-1)
		{
			b=a.charAt(i);
			if(b=='0')
			{
				if(v!='0')
				{
					v='0';
					c=0;
				}
				c=c+1;
			}
			else if(b=='1')
			{
				if(v!='1')
				{
					v='1';
					c=0;
				}
				c=c+1;
			}
			i++;
			if(c==7)
			{
				break;
			}
		}
		if(c==7)
		{
			System.out.println("YES");
		}
		else{
			System.out.println("NO");
		}
}
}