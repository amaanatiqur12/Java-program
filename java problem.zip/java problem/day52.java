import java.util.*;
public class day52{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b;
		int c;
		int k,m;
		int o,u=0;
		b=a;
		int g;
		int h=1;
		g=a;
		while(true)
		{
			
			b=a+h;
			u=0;
			g=b;
			while(b!=0)
			{
				k=b%10;
				b=b/10;
				c=b;
				while(c!=0)
				{
					m=c%10;
					c=c/10;
					if(k==m)
					{
						u=1;
						break;
					}
				}
				if(u==1)
				{
					break;
				}
			}
			if(u!=1)
			{
				break;
			}
			h++;
		}
		System.out.println(g);
	}
}