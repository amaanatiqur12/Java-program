import java.util.*;
public class day47{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		String b=input.next();
		
		char bb[]=b.toCharArray();
		char temp;
		for(int i=0,j=b.length()-1;i<=j;i++,j--)
		{
			temp=bb[i];
			bb[i]=bb[j];
			bb[j]=temp;
		}
		StringBuilder g=new StringBuilder();
		StringBuilder h=new StringBuilder(a);
		g.append(bb);
		
	
		if(g.toString().equals(h.toString()))
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}