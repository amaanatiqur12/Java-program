import java.util.*;
public class day36{
	public static void main(String[]args){
		Scanner  input=new Scanner(System.in);
		String a=input.next();
		int e=0;
		for(int i=0;i<=a.length()-1;i++)
		{
			if(a.charAt(i)=='H'||a.charAt(i)=='Q'||a.charAt(i)=='9'||)
			{
				e=1;
				break;
			}
		}
		if(e==1)
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}