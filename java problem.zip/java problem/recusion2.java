import java.util.*;
public class recusion2{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		for(int i=0;i<a;i++)
		{
			String b=input.next();
			Permutations(b,0,b.length()-1);
		}
	}
	public static String swap(String s,int f,int g)
	{
		char[] y=s.toCharArray();
		char temp=y[f];
		y[f]=y[g];
		y[g]=temp;
		return String.valueOf(y);
	}
	public static void Permutations(String s,int l,int r){
		if(l==r)
		{
			System.out.println(s);
			return;
		}
		for(int i=l;i<=r;i++)
		{
			s=swap(s,l,i);
			Permutations(s,l+1,r);
			s=swap(s,l,i);
		}
	}
}





















/**import java.util.*;
public class recusion2{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		for(int i=0;i<a;i++)
		{
			String b=input.next();
			Permutations(b,0,b.length()-1);
		}
	}
	public static String swap(String str, int i, int j)
    {
        char ch[] = str.toCharArray();
        char temp = ch[i];
        ch[i] = ch[j];
        ch[j] = temp;
        return String.valueOf(ch);
    }
	public static void Permutations(String s,int l,int r)//abc 0 2 - abc 1 2  
	{
		if(l==r) //abc 2 2 
		{
			System.out.println(s); //abc 
			return;
		}
		for(int i=l;i<=r;i++) // abc i=0,l=0 - abc 1 1
		{
			s=swap(s,l,i);//abc 0 0 - abc 1 1 
			Permutations(s,l+1, r);  // abc 1 2 
			s=swap(s,l,i);  // abc 2 2
			System.out.println(s+"- "+l+"- -"+i+"- ");
		}	
	}
}**/