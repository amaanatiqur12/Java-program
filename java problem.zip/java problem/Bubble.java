/**import java.util.*;
public class Bubble{
	public static void main(String [] args){
		Scanner input=new Scanner(System.in);
		int e=input.nextInt();
		int[] p=new int[e];
		for(int i=0;i<e;i++)
		{
			p[i]=input.nextInt();
		}
		int temp;
		for(int i=0;i<e;i++)
		{
			for(int j=0;j<e-1;j++)
			{
				if(p[j]>p[j+1])
				{
					
					temp = p[j];
					p[j] = p[j+1];
					p[j+1] = temp; 
					
				}
				
			}
		}
		for(int i=0;i<e;i++)
		{
			System.out.println(p[i]);
		}
	}
}**/

import java.util.*;
public class Bubble
{
	public static void main(String[]args){
		Scanner input = new Scanner(System.in);
		int i[]={4,3,12,-1,41,-55,33};
		for(int k=i.length-1;k>0;k--)
		{
			for(int j=0;j<k;j++)
			{
				if(i[j]>i[j+1])
				{
					swap(i,j,j+1);
				}
			}
		}
		for(int k=0;k<i.length;k++)
		{
			System.out.println(i[k]);
		}
	}
	public static void swap(int a[],int ii,int kk)
	{
		if(ii==kk)
			return;
		
		int temp = a[ii];
		a[ii] = a[kk];
		a[kk] = temp;
		
		
	}
}