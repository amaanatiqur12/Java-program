import java.util.*;
public class day22
{
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int c[]=new int[b];
		int d[]=new int[b];
		for(int i=0;i<=b-1;i++)
		{
			c[i]=input.nextInt();
			d[i]=input.nextInt();
		}
		int temp;
		for(int i=0;i<=c.length-1;i++)
		{
			for(int j=0;j<=c.length-2;j++)
			{
				if(c[j]>c[j+1])
				{
					temp=c[j];
					c[j]=c[j+1];
					c[j+1]=temp;
					temp=d[j];
					d[j]=d[j+1];
					d[j+1]=temp;
				}
			}
			
		}
		
		int e=0,w=7;
		while(e<=b-1)
		{
			if(a<=c[e])
			{
				w=1;
				break;
			}
			else
			{
				a=a+d[e];
			}
			e++;
		}
		if(w!=1)
		{
			System.out.println("YES");
		}
		else
		{
			System.out.println("NO");
		}
	}
}