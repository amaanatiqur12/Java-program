import java.util.*;
public class day71{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int[] b=new int[a];
		for(int i=0;i<a;i++){
			b[i]=input.nextInt();
		}
		int c,d,count=1;
		for(int i=0;i<a-1;i++)
		{
			c=b[i]%10;
			d=b[i+1]/10;
			if(c==d)
			{
				count++;
			}
		}
		System.out.println(count);
	}
}