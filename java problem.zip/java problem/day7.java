import java.util.*;
class day7
{
	public static StringBuffer  encrypt(String i,int j)
	{
		StringBuffer result=new StringBuffer();
		for(int a=0;a<i.length();a++)
		{
			if(Character.isUpperCase(i.charAt(a)))
			{
				char t=(char)(((int)i.charAt(a)+ j - 65 ) % 26 + 65);
				result.append(t);
			}
			else
			{
				char t=(char)(((int)i.charAt(a)+ j - 97 ) % 26 + 97);
				result.append(t);
			}
		}
		return result; 
	}
	
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		
			System.out.print("Enter a word:");
			String i=input.nextLine();
			boolean correct=false;
		
		while(!correct)
		{
			
		try
		{
			System.out.print("How many shift:");
			String value=input.next();
			int j=Integer.parseInt(value);
			correct=true;
			System.out.print("Encrypted :"+encrypt(i,j));
		}
		catch(NumberFormatException e)
		{
			System.out.print("Enter a integer:");
		}

		}
		
	
		
		
	}
}