import java.util.*;
public class day11{
	public static void main(String [] args){
		Scanner i=new Scanner(System.in);
		int p=i.nextInt();
		int z,c,a;
		if(p%2==0){
			int k=1;
			int r=2;
			while(r<=p){
				k++;
				if(k==2 || k==3 || k==5)
				{
					r=r+2;
				}	
					if(k%2!=0 && k%3!=0 && k%5!=0 )
					{
						r=r+2;
					}
				
			}
			System.out.print(k);
			
		}else
		{
			z=1;c=0;a=0;
			for(int r=1;r<=p;r=r+2)
			{
				a=c;
				c=z;
				z=a+c;
				
			}
			System.out.print(c);
		}
	}
}