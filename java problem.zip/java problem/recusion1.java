import java.util.*;
public class recusion1{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		powerset(a,0,"");
	}
	public static void powerset(String s,int i,String chr)
	{
		if(s.length()==i)
		{
			System.out.println(chr);
			return;
		}
		powerset(s,i+1,chr+s.charAt(i));
		powerset(s,i+1,chr);
	}
}