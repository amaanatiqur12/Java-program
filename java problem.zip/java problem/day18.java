import java.util.*;
public class day18{
	public static void main(String [] args)
	{
		Scanner input=new Scanner(System.in);
		String a=input.next();
		int b=0,c=2,d=2,e=0,f=2;
		while(b<=a.length()-1)
		{
			if(a.charAt(b)=='h'||c==1)
			{
				c=1;
				if(a.charAt(b)=='e'||d==1)
				{
					d=1;
					if(a.charAt(b)=='l'||e==2)
					{
						if(e!=2)
						{
							e=e+1;
						}
						if(a.charAt(b)=='o')
						{
							f=1;
							break;
						}
						
					}
					
				}
				
			}
			b++;
		}
		if(c==1&&d==1&&e==2&&f==1)
		{
			System.out.println("YES");
		}
		else
		{
			System.out.println("NO");
		}
			
	}
}