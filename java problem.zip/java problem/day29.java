import java.util.*;
public class day29{
	public static void main(String [] args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int c=input.nextInt();
		int u=0;
		for(int i=1;i<=c;i++)
		{
			u=u+a*i;
		}
		
		u=u-b;
		if(u>0)
		{
			System.out.println(u);
		}
		else{
			System.out.println(0);
		}
	}
}