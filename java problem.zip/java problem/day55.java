import java.util.*;
public class day55{
	public static void main(String []args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int[] c=new int[a];
		int u=0;
		for(int i=0;i<=a-1;i++)
		{
			c[i]=input.nextInt();
			if(c[i]>b)
			{
				u++;
			}
		}
		int k=u*2+a-u;
		System.out.println(k);
	}
}