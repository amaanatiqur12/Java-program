import java.util.*;
public class day9{
	public static void main(String[]args)
	{
		String a,b,c,w;
		Scanner o=new Scanner(System.in);
		a=o.nextLine();
		b=o.nextLine();
		c=o.nextLine();
		StringBuilder q=new StringBuilder(a);
		StringBuilder j=new StringBuilder(b);
		for(int i=0;i<=a.length()-1;i++)
		{
			w=a.toLowerCase();
			if(w.charAt(i)=='a' || w.charAt(i)=='e' || w.charAt(i)=='i' || w.charAt(i)=='o' || w.charAt(i)=='u')
			{
				
				char y='*';
				q.setCharAt(i, y); 
			}
		}
			a=q.toString();
			
			for(int i=0;i<=b.length()-1;i++)
		{
			w=b.toLowerCase();
			if(w.charAt(i)!='a' && w.charAt(i)!='e' && w.charAt(i)!='i' && w.charAt(i)!='o' && w.charAt(i)!='u')
			{
				
				char y='@';
				j.setCharAt(i, y); 
			}
		}
			b=j.toString();
			
		c=c.toUpperCase();
		
		String tt=a+b+c;
		System.out.print(tt);
			
	}
}