import java.util.*;
public class day92{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.next().toLowerCase();
		char[] b=a.replaceAll("[AaEeIiOoUu]", "").toCharArray();
		String c="";
		for(int i=0;i<b.length-1;i++)
		{
			if((int)b[i]>=97&&(int)b[i]<=122)
				c+="*"+String.valueOf(b[i]);
			else
				c+=String.valueOf(b[i]);
		}
		System.out.println(c);
	}
}