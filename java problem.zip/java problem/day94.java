import java.util.*;
public class day94{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int i=input.nextInt();
		int k=1;
		ArrayList<String> a=new ArrayList<>();
		for(int p=0;p<i;p++)
		{
			String c="";
			for(int u=0;u<=p;u++)
			{
				c+=String.valueOf(k)+"*";
				k++;
			}
			c=c.substring(0,c.length()-1);
			a.add(c);
		}
		for(int p=0;p<a.size();p++)
			System.out.println(a.get(p));
		for(int p=a.size()-1;p>=0;p--)
			System.out.println(a.get(p));
	}
}