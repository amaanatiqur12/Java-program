import java.util.*;
public class day4{
	public static void main(String[]args)
	{
		int r,i=0,y,k;
		Scanner input=new Scanner(System.in);
		r=input.nextInt();
		
			y=input.nextInt();
			k=input.nextInt();
			int a[]=new int[y];
			  
			for(int l=0;l<a.length;l++)
			{
				a[l]=input.nextInt();
			}
			 
		
	}
}
