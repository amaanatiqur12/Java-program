import java.util.*;
public class Dreamoon{
	public static int k=0;
	public static int t=-1;

	public static int[] c=new int[1]; 
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		c[0]=Integer.MAX_VALUE;
		int k=mimStair(a,b);
		if(k==Integer.MAX_VALUE)
		{
			k=-1;
		}
		System.out.println(k);
	}
	
	public static int mimStair(int a,int b){
		t++;
		
		if(a==0)
		{
			if(t%b==0)
			{
				if(c[0]>t)
				{
					c[0]=t;
				}
			}
			
			return 0;
		
		}
		if(a<0)
		{
			
			return 0;
		}
		
		for(int i=1;i<=2;i++)
		{
			

			mimStair(a-i,b);
			t=t-1;
		}
		
		
		
		return c[0];
	}
}