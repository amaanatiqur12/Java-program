import java.util.*;
public class day65{
	public static void main(String[]args)
	{
		Scanner input=new Scanner(System.in);
		String s=input.next();
		int count=0;
		String d="";
		ArrayList o=new ArrayList();
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)=='(')
			{
				count+=1;
				d+=String.valueOf(s.charAt(i));
			}
			else if(s.charAt(i)==')')
			{
				count+=-1;
				d+=String.valueOf(s.charAt(i));
			}
			if(count==0)
			{
				o.add(d);
				d="";
			}
		}
		System.out.println(Arrays.toString(o.toArray()));
	}
}