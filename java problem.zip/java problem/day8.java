import java.util.*;
public class day8{
	public static void main(String []args)
	{
		int y;
		Scanner h=new Scanner(System.in);
		y=h.nextInt();
		int z=1;
		if(y%2==0){
			for(int i=2;i<=y-1;i=i+2)
			{
				z=z*3;
			}
			
		}
		else{
			for(int i=1;i<=y-1;i=i+2)
			{
				z=z*2;
			}
		}
		System.out.print(z);
	}
}
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sin = new Scanner(System.in);
		int n = sin.nextInt();
		System.out.println(n%2==0?(int)Math.pow(3,(n-1)/2):(int)Math.pow(2,(n-1)/2));
	}
}
// we have used ternary operator above condition ? value_if_true : value_if_false