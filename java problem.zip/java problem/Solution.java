import java.io.*;
import java.util.*;
//Wrong solution not shorted properlyl;
public class Solution {

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int a=input.nextInt();
        int b[]=new int[a];
        for(int i=0;i<=a-1;i++)
        {
            b[i]=input.nextInt();
        }
        int c=input.nextInt();
        List array=new ArrayList();
        for(int i=0;i<=a-1;i++)
        {
            if(b[i]<c)
            {
                array.add(b[i]);
            }
        }
        int x=0;
        int k=0,g,sum=0;
        List combined=new ArrayList();
        int w=0;
        while(k<=array.size()-1)
        {
            g=(int)array.get(k);
            combined.add(array.get(k));
            sum=g;
            for(int j=k+1;j<=array.size()-1;j++)
            {
				sum=g;
                for(int i=j;i<=array.size()-1;i++)
                {
                    sum=sum+(int)array.get(i);
                    combined.add(array.get(i));
                    if(sum==c)
                    {
                        w=1;
                        break;
                    }
                    else if(sum>c)
                    {
                    
                        int p=combined.size()-1;
                        combined.remove(p);
                        sum=sum-(int)array.get(i);
                    }
                }
				
                if(w==1)
                {
                    break;
                }
				combined.clear();
				combined.add(array.get(k));
            }
            if(w==1)
            {
                break;
            }
            combined.clear();
            k++;
        }
		int uu=0;
        if(w!=1)
        {
        k=array.size()-1;
		
        while(k>=0)
        {
            g=(int)array.get(k);
            combined.add(array.get(k));
            sum=g;
            for(int j=k-1;j>=0;j--)
            {
				sum=g;
                for(int i=j;i>=0;i--)
                {
                    sum=sum+(int)array.get(i);
					
                    combined.add(array.get(i));
                    if(sum==c)
                    {
                        uu=1;
						
                        break;
                    }
                    else if(sum>c)
                    {
                    
                        int p=combined.size()-1;
                        combined.remove(p);
                        sum=sum-(int)array.get(i);
                    }
                }
				
                if(uu==1)
                {
                    break;
                }
				combined.clear();
				combined.add(array.get(k));
            }
            if(uu==1)
            {
                break;
            }
            combined.clear();
            k--;
        }
        }
        if(combined.size()==0)
        {
            System.out.println("-1");
        }
        else if(w==1){
            for(int i=0;i<=combined.size()-1;i++)
            {
                System.out.print(combined.get(i)+" ");
            }  
        }
		else if(uu==1){
			for(int i=combined.size()-1;i>=0;i--)
            {
                System.out.print(combined.get(i)+" ");
            }  
		}
        
    }
}
/**import java.io.*;
import java.util.*;
//Wrong solution not shorted properlyl;
class Solution{
   
    public static int subArraySum(int arr[], int n, int sum)
    {
        int curr_sum, i, j;
 
        // Pick a starting point
        for (i = 0; i < n; i++) {
            curr_sum = arr[i];
 
            // try all subarrays starting with 'i'
            for (j = i + 1; j <= n; j++) {
                if (curr_sum == sum) {
                    int p = j - 1;
                    System.out.println(
                        "Sum found between indexes " + i
                        + " and " + p);
                    return 1;
                }
                if (curr_sum > sum || j == n)
                    break;
                curr_sum = curr_sum + arr[j];
            }
        }
 
        System.out.println("No subarray found");
        return 0;
    }
 
    public static void main(String[] args)
    {
        
		Scanner input=new Scanner(System.in);
		int n = input.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<=n-1;i++)
		{
			arr[i]=input.nextInt();
		}
        
        
        int sum = input.nextInt();
        subArraySum(arr, n, sum);
    }
}**/
 
