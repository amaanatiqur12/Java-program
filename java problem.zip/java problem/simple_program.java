import java.util.*;
public class simple_program{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
	}
}
/**import java.util.*;
public class simple_program{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int count=0;
		int v=input.nextInt();
		int k=v;
		while(k!=0)
		{
			count=count+1;
			k=k/10;
		}
		int u;
		k=v;
		int reverse=0;
		//System.out.println(count);
		for(int i=0;i<count;i++)
		{
			u=k%10;
			//System.out.println(u);
			reverse=reverse*10+u;
			k=k/10;
		}
		System.out.println(reverse);
	}
}**/
/**import java.util.*;
public class simple_program{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int i=input.nextInt();
		int k=i;
		int l=0;
		int count=0;
		while(k!=0)
		{
			count=count+1;
			k=k/10;
		}
		k=i;
		//System.out.println(k%10+"<=>"+count);
		while(k!=0)
		{
			//System.out.println(k%10);
			//System.out.println(Math.pow(k%10,count));
			l+=Math.pow(k%10,count);
			k=k/10;	
		}
		if(l==i)
			System.out.println("YES");
		else
			System.out.println("NO"+""+l);
	}
}**/