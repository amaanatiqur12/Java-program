import java.util.*;
public class day101{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int even=0;
		int odd=0;
		String[] a=input.next().split("");
		for(int i=0;i<a.length;i++)
		{
			if(Integer.parseInt(a[i])%2==0)
				even+=Integer.parseInt(a[i]);
			else
				odd+=Integer.parseInt(a[i]);
		}
		System.out.println(even+" "+odd);
	}
}