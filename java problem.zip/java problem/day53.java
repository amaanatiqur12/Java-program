import java.math.BigInteger;
import java.util.*;
public class day53{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		String c="1";
		int d=0;
		for(int i=1;i<=a-1;i++)
		{
			c=c+"0";
		}
		BigInteger g,B,f,A,O;		
		g=new BigInteger(c+"0");
		
		f=new BigInteger(c);
		
		B=BigInteger.valueOf(b);
		A = BigInteger.ONE;
		O = BigInteger.ZERO;
		
		
		int t= f.remainder(B).compareTo(O);
		
		Boolean H = f.divide(g).equals(O);
		while(t!=0&&H)
		{
			
			f=f.add(A);
			
			t= f.remainder(B).compareTo(O);
			
			H = f.divide(g).equals(O);
		}
		
		H = f.divide(g).equals(O);
		if(!H)
		{
			System.out.println("-1");
		}
		else
		{
			System.out.println(f);
		}
	}
}