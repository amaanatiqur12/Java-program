import java.util.*;
public class day66{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		int zz
		for(int i=0;i<a.length()-1;i++)
		{
			int u=a.xharAt()
		}
	}
}