import java.util.*;
public class day24{
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		String a=input.next();
		int shift=input.nextInt();
		int k=0;
		String j="";
		while(k<=a.length()-1)
		{
			char o=a.charAt(k);
			int c=o;
			if(c>=97&&c<=122)
			{
				char e=(char)((c+shift-97)%26+97);
				j=j+e;
			}
			if(c>=65&&c<=90)
			{
				char e=(char)((c+shift-65)%26+65);
				
				j=j+e;
			}
			k++;
		}
		System.out.println(j);
	}
}