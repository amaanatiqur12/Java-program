import java.util.*;
public class practise{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int five=0;
		int two=0;
		int one=0;
		five=(a-4)/5;
		if(((a-five*5)%2)==0)
			one=2;
		else
			one=1;
		two=(a-five*5-one)/2;
		System.out.println(five*5+one+two*2);
		System.out.println(five*5);
		System.out.println(two*2);
		System.out.println(one);
	}
}