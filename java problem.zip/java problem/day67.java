import java.util.*;
public class day67{
	public static void main(String[]args){
		Scanner input =new Scanner(System.in);
		String text=input.next();
		int a,l;
        String c="",m;
       ArrayList<String> o=new ArrayList<>();
       //StringBuilder input1 = new StringBuilder();
        
       for(int i=0;i<text.length();i++)
       {
           for(int j=text.length();j>=0&&i!=j;j--)
           {
			  StringBuilder input1 = new StringBuilder();
              c=subString(text,j,i);
			  System.out.println(c);
			 
              input1.append(c);
              m=String.valueOf(input1.reverse());
              
              if(c.equals(m))
              {
                  o.add(c);
              }
              
           }
       }
	   
       String max="";
       if(o.size()>0)
       {
             max=String.valueOf(o.get(0));
       }
       String normal="";
       for(int i=1;i<o.size();i++)
       {
           normal=o.get(i);
           if(max.length()<normal.length())
           {
               max=normal;
           }
       }
       System.out.println(max);
    }
 
	 public static String subString(String a,int b,int c)
	{
		return a.substring(c,b);
	}	 
}
