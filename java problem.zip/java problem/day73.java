 import java.util.*;
 public class day73{
	public static void main(String[] args){
		Scanner input=new Scanner(System.in);
		int i = input.nextInt();
		
		String a = Integer.toString(i);
		if(i<0)
		{
			int g = a.length()-1;
			int c = Integer.parseInt(String.valueOf(a.charAt(g)));
			//System.out.println(c);
			int d = Integer.parseInt(String.valueOf(a.charAt(g-1)));
			//System.out.println(d);
			if(c >= d)
			{
				a = SubString(a,a.length()-2,a.length()-2,a.length()-1);
				//System.out.println(1);
			}
			else
			{
				a = SubString(a,a.length()-2,a.length()-1,a.length());
				//System.out.println(2);
			}
			i = Integer.parseInt(a);
			if(i==-0)
			{
				i=0;
			}
		}
		System.out.println(i);
	}
	public static String SubString(String aa,int bb,int dd,int cc)
	{
		return aa.substring(0,bb)+aa.substring(dd,cc);
	}
 }