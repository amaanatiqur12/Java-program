import java.util.*;

public class gameJump {
    
    public static boolean canWin(int leap,int[] game) {
        int a[]={1,leap};
        return canWin(game,0,a);
    }
    public static boolean decision=false;
    public static boolean canWin(int[] game,int index,int[] a) {
        
        
        
       
        for(int i=0;i<=1&&game[index]!=1;i++)
        {  
            
            if(index+a[i]>=game.length-1||decision==true)
            {
                decision=true;
                break;
            }
            if(game[index+a[i]]==1)
            {
               continue;
            } 
            canWin(game,index+a[i],a);
           
            
        } 
        return decision;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int q = scan.nextInt();
		
		int leap=scan.nextInt();
		
		int game[]=new int[q];
		
		for(int i=0;i<=q-1;i++)
		{
			game[i]=scan.nextInt();
		}
		
        System.out.println( (canWin(leap, game)) ? "YES" : "NO" );
       
       
    }
}