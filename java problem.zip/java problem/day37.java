import java.util.*;
public class day37{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.nextLine();
		String[] b=a.split(" ");
		HashMap<String,Integer> c=new HashMap<>();
		for(String d : b)
		{
			if(c.get(d)!=null)
			{
				c.put(d,c.get(d)+1);
			}
			else
			{
				c.put(d,1);
			}
		}
		Iterator<String> e=c.keySet().iterator();
		while(e.hasNext())
		{
			String temp=e.next();
			if(c.get(temp)>1)
			{
				System.out.println(temp+" is repeated "+c.get(temp)+" times ");
			}
		}
	}
}