import java.util.*;
public class day54{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int[] b=new int[a];
		String[] c=new String[a];
		for(int i=0;i<=a-1;i++)
		{
			b[i]=input.nextInt();
			c[i]=input.next();
		}
		int w=0,q=0,o;
		int y=0;
		char ll,kk,jj,hh;
		String lll;
		int[] d=new int[a];
		while(y<=a-1)
		{
			o=b[y];
			int k=0;
			lll=c[y];
			while(k<=o-1)
			{
				ll=lll.charAt(k);
				if(ll=='(')
				{
					w++;
				}
				else{
					if(w>0)
					{
						w--;
					}
					
				}
				
				k++;
			}
			d[y]=w;
			w=0;
			q=0;
			y++;
		}
		for(int i=0;i<=a-1;i++)
		{
			System.out.println(d[i]);
		}
	}
}