import java.util.*;
public class day31{
	public static void main(String[]args)
	{
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int c=0;
		while(a<=b)
		{
			a=a*3;
			b=b*2;
			c++;
		}
		System.out.println(c);
	}
}