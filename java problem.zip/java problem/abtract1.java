import java.util.*;
interface class song{
	String breed;
	public  void dog(){
		System.out.println("dog1");
	}
	public abstract int  goat();
}
class dog1 extends song{
	public int goat()
	{
		System.out.println("Amaan");
		return 3;
	}
}
public class abtract1{
	public static void main(String[]args){
		dog1 r=new dog1();
		r.dog();
	}
}