import java.util.*;
import java.math.*;
public class day56{
	public static void main(String[]args){
		BigInteger E;
		Scanner input=new Scanner(System.in);
		String a=input.next();
		BigInteger A=new BigInteger(a);
		String b=input.next();
		BigInteger B=new BigInteger(b);
		BigInteger C=A.divide(BigInteger.TWO);
		BigInteger D=A.subtract(C);
		
		if(B.compareTo(D)==-1||B.compareTo(D)==0)
		{
			E=B.multiply(BigInteger.TWO);
			E=E.subtract(BigInteger.ONE);
		}
		else
		{
			BigInteger F=B.subtract(D);
			 E=F.multiply(BigInteger.TWO);
		}
		System.out.println(E);
	}
}