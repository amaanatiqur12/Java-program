import java.util.*;
public class day76{
	public static void main(String [] args){
		 Scanner input=new Scanner(System.in);
		 int p=input.nextInt();
		 ArrayList<ArrayList<Integer> > aList = new ArrayList<ArrayList<Integer> >();
		 for(int i=0;i<=p-1;i++)
		 {
			 int k=input.nextInt();
			 ArrayList<Integer> Listq=new ArrayList<Integer>();
			 for(int j=0;j<=k-1;j++)
			 {
				 int v=input.nextInt();
				 Listq.add(v);
			 }
			 aList.add(Listq);
		 }
		 //System.out.println(aList.get(0).size()-1);
		 ArrayList<ArrayList<Integer> > aList2 = new ArrayList<ArrayList<Integer> >();
		 
		 for(int i=0;i<=p-1;i++)
		 {   // 3 4 5 2 9 1 1 
			//System.out.println("-----------------------------------");
			ArrayList<Integer> Listq2=new ArrayList<Integer>();
			 for(int j=0,w=aList.get(i).size()-1,z=0;j<=(aList.get(i).size()-1)/2&&w>=(aList.get(i).size()-1)/2;j++,w--)
			 {
				 
				 // System.out.println("-----------------------------------");
				 // System.out.println(z);
				 if(z<=aList.get(i).size()-1)
				 {
					//System.out.println(z);
					Listq2.add(aList.get(i).get(j)); 
				 }
				 z++;
				 if(z<=aList.get(i).size()-1)
				 {
					//System.out.println(z);
					Listq2.add(aList.get(i).get(w)); 
				 }
				 z++;
			 }
			 aList2.add(Listq2);
		 }
		// System.out.println(aList2.get(0).size()-1);
		 for(int i=0;i<=p-1;i++)
		 {
			 for(int j=0;j<=aList2.get(i).size()-1;j++)
			 {
				 System.out.print(aList2.get(i).get(j)+" ");
			 }
			 System.out.println();
		 }
	}
}