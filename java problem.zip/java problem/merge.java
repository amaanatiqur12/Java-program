import java.util.*;
public class merge{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int[] b=new int[a];
		for(int i=0;i<a;i++)
			b[i]=input.nextInt();
		mergesort(b,0,b.length-1);
		for(int i=0;i<a;i++)
			System.out.println(b[i]);
	}
	public static void mergesort(int[] d,int l,int r)
	{
		if(l<r)
		{
			int mid=(l+r)/2;
			mergesort(d,l,mid); 
			mergesort(d,mid+1,r);
			merge(d,l,mid,r);
		}
	}
	public static void merge(int[] d,int l,int mid,int r)
	{
		int x=l;
		int y=mid+1;
		int z=l;
		int[] s=new int[r+1];
		while(x<=mid&&y<=r)
		{
			if(d[x]>d[y]) 
			{
				s[z]=d[y];
				y++;
			}
			else
			{
				s[z]=d[x];
				x++;
			}
			z++;
		}
		if(x>mid)
		{
			while(y<=r)
			{
				s[z]=d[y];
				y++;
				z++;
			}
		}
		else
		{
			while(x<=mid)
			{
				s[z]=d[x];
				x++;
				z++;
			}
		}
		for(int i=l;i<=r;i++)
		{
			d[i]=s[i];
			System.out.println(d[i]+" ");
		}
		System.out.println("");
	}
}