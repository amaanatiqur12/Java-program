import java.util.*;
public class day2{
	public static void main(String[]args)
	{
		Scanner input=new Scanner(System.in);
		
		int q=input.nextInt(); 
		//input.next();
		String e[]=new String[q];
		for(int k=0;k<=q-1;k++)
		{
			//System.out.print(k);
			e[k]=input.next();
		}
		//System.out.print(e[0]);
		int y=0;
		while(y<=q-1)
		{
			String d=e[y];
			int w=d.length();
			if(w<11)
			{
				System.out.println(d);
			}
			else{
				char first_char=d.charAt(0);
				char last_char=d.charAt(w-1);
				w=w-2;
				System.out.println(first_char+""+w+""+last_char);
			}
		   y++;
		}
		 
	}
}