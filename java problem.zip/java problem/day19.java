import java.util.*;
public class day19{
	public static void main(String [] args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=2,c,e,r=9;
		while(b<=a/2)
		{
			e=b;
			while(e!=0)
			{
				c=e%10;
			
				if(c!=4&&c!=7)
				{
					
					break;
				}
				e=e/10;
			}
			
			if(e==0)
			{
				
				if(a%b==0)
				{
					
					
					r=1;
					break;
				}
			}
			b++;
		}
		e=a;
		while(e!=0)
		{
			c=e%10;
			
			if(c!=4&&c!=7)
			{
				
				break;
			}
			e=e/10;
		}
		
		
		if(r==1||e==0)
		{
			System.out.println("YES");
		}
		else
		{
			System.out.println("NO");
		}
	}
}