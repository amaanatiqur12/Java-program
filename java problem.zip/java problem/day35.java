import java.util.*;
public class day35{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b[]=new int[a];
		for(int i=0;i<=a-1;i++)
		{
			b[i]=input.nextInt();
		}
		int temp;
		int d=0;
		for(int i=0;i<=a-1;i++)
		{
			d=d+b[i];
		}
		for(int i=0;i<=a-1;i++)
		{
			for(int j=0;j<=a-2;j++)
			{
				if(b[j]<b[j+1])
				{
					temp=b[j];
					b[j]=b[j+1];
					b[j+1]=temp;
				}
			}
		}
		
		d=d/2;
		int c=0;
		int e=0;
		while(c<=d)
		{
			c=c+b[e];
			e++;
		}
		
		System.out.println(e);
		
	}
}