import java.util.*;
public class password{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a="mcleod215russel6289878";
		for(int i=0;i<=21;i++)
		{
			char b=a.charAt(i);
			if(b>96&&b<=122)
			{
				int bb=b+1;
				char c=(char)bb;
				if(c>=122)
				{
					c='a';
				}
				while(b!=c)
				{
					
					System.out.println(subString(i,a,c));
					if(c>=122)
					{
						c='a';
						bb=97;
					}
				    else
					{
						bb=bb+1;
						c=(char)bb;
					}
				}
				int l=0;
				while(l<=9)
				{
					System.out.println(subString(i,a,l));
					l++;
				}
			}
			else{
				int bb=0;
				int z=Integer.parseInt(String.valueOf(b));
				
				while(bb<=9)
				{	
					
					if(z!=bb)
					{
						System.out.println(subString(i,a,bb));
						
					}
					bb++;
				}
				char h='a';
				int m=1;
				while(m<=26)
				{
					System.out.println(subString(i,a,h));
					int j=h+1;
					h=(char)j;
					m++;
				}
			}
		}
	}
	public static String subString(int i,String a,char c)
	{
		String e=a.substring(0,i);
		String g=a.substring(i+1);
		String f=String.valueOf(c);
		
		return e+f+g;
		
	}
	public static String subString(int i,String a,int c)
	{
		String e=a.substring(0,i);
		String g=a.substring(i+1);
		String f=String.valueOf(c);
		
		return e+f+g;
		
	}
}