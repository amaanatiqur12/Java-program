import java.util.*;
public class day32{
	public static void main(String [] args)
	{
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int c=0,d;
		while(c<=b-1)
		{
			d=a%10;
			if(d!=0)
			{
				a=a-1;
			}else
			{
				a=a/10;
			}
			c++;
		}
		System.out.println(a);
	}
}