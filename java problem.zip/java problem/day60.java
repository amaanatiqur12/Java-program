import java.util.*;
public class day60{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int c=input.nextInt();
		int d=a-c;
		
		if(d-b<1)
		{
			while(d-b<1)
			{
				d++;
			}
		}
		
		System.out.println(a-d+1);
	}
}