import java.util.*;
public class day107{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		String[] b=new String[a*(a-1)/2];
		input.nextLine();
		for(int i=0;i<a*(a-1)/2;i++)
			b[i]=input.nextLine();
		HashMap<String,Integer> c=new HashMap<>();
		for(int i=0;i<b.length;i++)
		{
			String[] d=b[i].split(" ");
			String[] e=d[2].split("-");
			int[] f=new int[2];
			for(int  j=0;j<2;j++)
				c.put(d[j],c.getOrDefault(d[j],0)+Integer.parseInt(e[j]));
		}
		int k=1;
		//System.out.println(c.keys);
		for(String key:c.keySet())
		{
			if(k==c.size())
				System.out.println(key);
			k++;
		}
		k=1;
		//System.out.println(c.keys);
		for(int value:c.values())
		{
			if(k==c.size())
				System.out.println(value);
			k++;
		}
	}
	
}