import java.util.*;
public class day21{
	public static void main(String [] args)
	{
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int c=input.nextInt();
		int d,e,f,g,h,p;
		d=a*b*c;
		e=a*(b+c);
		f=(a+b)*c;
		g=a*b+c;
		p=a+b+c;
		h=a+b*c;
		int[] v={d,e,f,g,h,p};
		int temp=v[0];
	
		for(int i=0;i<=v.length-1;i++)
		{
			if(temp<v[i])
			{
				temp=v[i];
			}
		}
		System.out.println(temp);
	}
	
}