import java.util.*;
public class day27{
	public static void main(String[] args){
		Scanner input=new Scanner(System.in);
		String g=input.next();
		int i=0,j=0,k=0,m;
		char b;
		for(int a=0;a<=g.length()-1;a=a+2)
		{
			b=g.charAt(a);
			
			m=Integer.parseInt(String.valueOf(b));;
			
			if(m==1)
			{
				i++;
			}
			else if(m==2){
				j++;
			}
			else if(m==3){
				k++;
			}
		}
		String v="";
		for(int a=0;a<=i-1;a++)
		{
			v=v+"1+";
		}
		for(int a=0;a<=j-1;a++)
		{
			v=v+"2+";
		}
		for(int a=0;a<=k-1;a++)
		{
			v=v+"3+";
		}
		v=removeString(v,g.length());
		System.out.println(v);
	}
	public static String removeString(String h,int q)
	{
		return h.substring(0,q)+h.substring(q+1);
	}
}