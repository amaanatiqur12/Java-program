import java.util.*;
public class day85{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String[] a=input.next().split(":");
		StringBuilder input1 = new StringBuilder();
		input1.append(a[0]);
		input1.reverse();
		int b=Integer.parseInt(input1.toString());
		
		b=(b<Integer.parseInt(a[1]))?b+60-Integer.parseInt(a[1]):b-Integer.parseInt(a[1]);
		System.out.println(b);
		}
}