import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class coinChange{

    // Complete the ways function below.
    static long ways(int n, int[] coins) {

        return ways(n,coins,0,new HashMap<String,Long>());
    }
    public static long ways(int money,int[] coins,int index,HashMap<String,Long>memo){
        if(money==0)
        {
            return 1;
        }
        if(index>=coins.length)
        {
            return 0;
        }
        String key = money+ "-" +index;
		System.out.println(key+"-------------");
        if(memo.containsKey(key))
        {
            return memo.get(key);    
        }
        int amountWithCoin=0;
        long ways=0;
        while(amountWithCoin<=money)
        {
			System.out.println("----------------------");
            int remaining=money-amountWithCoin;
            ways+=ways(remaining,coins,index+1,memo);
			System.out.println(ways+" = "+index+" = "+remaining+" = "+money);
            amountWithCoin+=coins[index];
        }
        memo.put(key,ways);
        return ways;
    }
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        

        int n = scanner.nextInt();
		

        int m = scanner.nextInt();

		int[] coins=new int[m];

        for (int i = 0; i < m; i++) {
            coins[i]=scanner.nextInt();
        }

        long res = ways(n, coins);

       System.out.println(res);
    }
}
