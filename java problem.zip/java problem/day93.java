import java.util.*;
public class day93{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String[] a=input.nextLine().split(" ");
		//System.out.println(Arrays.toString(a));
		double[] b=new double[2];
		for(int i=0;i<=1;i++)
		{
			b[i]=Double.parseDouble(a[i]);
		}
		double[] c=new double[4]; 
		
		c[0]=b[0]+b[1];
		c[1]=b[0]-b[1];
		c[2]=b[0]*b[1];
		c[3]=b[0]/b[1];
		
		Arrays.sort(c);
		
		System.out.println(c[c.length-1]);
	}
}