import java.util.*;
public class day51{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int o=a;
		int c;
		int g;
		while(a>=b)
		{
			g=a%b;
			a=a-g;
			c=a/b;
			
			a=c+g;
			o=o+c;
		}
		System.out.println(o);
	}
}