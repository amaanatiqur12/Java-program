import java.util.*;
public class day91{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String[] a=input.nextLine().split(" ");
		
		int sum=input.nextInt();
		
		int[] b=new int[a.length];
		for(int i=0;i<a.length;i++)
		{
			b[i]=Integer.parseInt(a[i]);
		}
		int temp=0;
		int ans=0;
		int v=0;
		for(int i=0;i<b.length;i++)
		{
			temp=b[i];
			for(int j=i+1;j<b.length;j++)
			{
				
				if(temp+b[j]==sum)
				{
					
					v=1;
					ans=b[j];
					break;
				}
			}
			if(v==1)
			{
				break;
			}
		}
		if(v==1)
		{
			System.out.println(temp+" "+ans);
		}
		else
		{
			System.out.println("Not Found");
		}
	} 
}