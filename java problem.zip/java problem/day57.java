import java.util.*;
public class day57{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int[] b=new int[a];
		for(int i=0;i<=a-1;i++)
		{
			b[i]=input.nextInt();
		}
		int temp;
		for(int i=0;i<=a-1;i++)
		{
			for(int j=0;j<=a-2;j++)
			{
			 if(b[j]>b[j+1])
			 {
				 temp=b[j];
				 b[j]=b[j+1];
				 b[j+1]=temp;
			 }
			}
		}
		for(int i=0;i<=a-1;i++)
		{
			System.out.println(b[i]);
		}
	}
}