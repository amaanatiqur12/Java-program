import java.util.*;
class dog
{
	private int roll;
	private String name;
	public void nameadd(String Nameadd)
	{
		name=Nameadd;
	}
	public String nameadd()
	{
		return name;
	}
	public void nameroll(int rolladd)
	{
		roll=rolladd;
	}
	public int nameroll()
	{
		return roll;
	}
	
}
public class Encapsulation{
	public static void main(String[]args){
		dog g=new dog();
		g.nameadd("Amaan");
		System.out.println(g.nameadd());
		g.nameroll(17);
		System.out.println(g.nameroll());
	}
}