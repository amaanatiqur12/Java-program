import java.util.*;
public class day86{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);	
		String[] a=input.nextLine().split(" ");
		int[] b=new int[a.length];
		for(int i=0;i<a.length;i++)
		{
			b[i]=Integer.parseInt(a[i]);
		}
		int maxSum=0;
		int sum=0;
		int i=0;
		int k=-1;
		ArrayList<Integer> c=new ArrayList<Integer>();
		ArrayList<Integer> d=new ArrayList<Integer>();
		while(i<a.length)
		{
			sum+=b[i];
			c.add(b[i]);
			if(sum>maxSum)
			{
				if(k==1)
				{
					d.clear();
					k=0;
				}
				maxSum=sum;
				d.addAll(c);
				c.clear();
			}
			if(sum<0)
			{
				sum=0;
				c.clear();
				k=1;
			}
			i++;
		}
		System.out.println(d);
	}
}