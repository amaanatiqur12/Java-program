import java.util.*;
public class day98{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String[] a=input.nextLine().split(" ");
		int b=input.nextInt();
		int[] c=new int[a.length];
		for(int i=0;i<a.length;i++)
			c[i]=Integer.parseInt(a[i]);
		Arrays.sort(c);
		int sum=0;
		for(int i=a.length-1;i>a.length-1-b;i--)
			sum+=c[i];
		System.out.println(sum);
	}
}