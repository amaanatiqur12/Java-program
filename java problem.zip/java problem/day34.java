import java.util.*;
public class day34{
	public static void main(String [] args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=0;
		int c;
		
			if(a/5!=0)
			{
				c=a/5;
				a=a-c*5;
				b=b+c;
			}
			if(a/4!=0)
			{
				c=a/4;
				a=a-c*4;
				b=b+c;
			}
			if(a/3!=0)
			{
				c=a/3;
				a=a-c*3;
				b=b+c;
			}
			if(a/2!=0)
			{
				c=a/2;
				a=a-c*2;
				b=b+c;
			}
			if(a/1!=0)
			{
				c=a/1;
				a=a-c*1;
				b=b+c;
			}
		System.out.println(b);	
	}
}