import java.util.*;
public class java22{
	public static void main(String[] args){
		Scanner input=new Scanner(System.in);
		int i=12345;
		System.out.println(i%100);
	}
}