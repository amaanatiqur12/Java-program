import java.util.*;
public class Insertion{
	public static void main(String[]args){
		int[] a={4,3,2,55,6,78,-1,32};
		for(int i=1;i<a.length;i++)
		{
			int j=a[i];
			int p;
			for(p=i;p>0&&a[p-1]>j;p--)
			{
				a[p]=a[p-1];
			}
			a[p]=j;
		}
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
}




/**import java.util.*;
public class Insertion{
	public static void main(String[]args){
		int[] a={4,3,2,55,6,78,-1,32};
		for(int i=0;i<a.length;i++)
		{
			
			int b=i;
			for(int j=i-1;j>=0;j--)
			{
				if(a[j]>a[b])
				{
					
					swap(a,b,j);
					b=j;
				}
				else
				{
					break;
				}
			}
		}
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
	public static void swap(int[] u,int ii,int jj)
	{
		int temp=u[ii];
		u[ii]=u[jj];
		u[jj]=temp;
		
	}
}**/