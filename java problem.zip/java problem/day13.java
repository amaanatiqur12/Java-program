import java.util.*;
public class day13{
	public static void main(String [] args)
	{
		Scanner input=new Scanner(System.in);
		int y=input.nextInt();
		String a[]=new String[y];
		for(int i=0;i<=y-1;i++)
		{
			a[i]=input.next();
		}
		int i=0;
		int x=0;
		while(i<=y-1)
		{
			
			if(a[i].equals("X++")||a[i].equals("++X"))
			{
				
				x++;
			}
			else if(a[i].equals("X--")||a[i].equals("--X")){
				x--;
			}
			i++;
		}
		System.out.println(x);
	}
}