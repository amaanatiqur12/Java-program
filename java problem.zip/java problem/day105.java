import java.util.*;
public class day105{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int count=0;
		for(int i=a+1;i<=b;i++)
		{
			String[] d=String.valueOf(i).split("");
			if(Arrays.stream(d).distinct().count()==d.length)
				count++;
		}
		System.out.println(count);
	}
}