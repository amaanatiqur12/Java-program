import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class day30 {
    // Complete the biggerIsGreater function below.
    static String replaceChar(int e,int f,String g)
    {
        String q=g.substring(0,e);
        char p=g.charAt(f);
        String dd= String.valueOf(p);
        q=q+dd;
        String hh=g.substring(e+1,f)+g.substring(f+1);
        char ww=g.charAt(e);
        String www=String.valueOf(ww);
        www=hh+www;
        char tempArray[] = www.toCharArray();     
        Arrays.sort(tempArray);
        www=new String(tempArray);
        q=q+www;
        return q;
    }
        static String biggerIsGreater(String w) {
    
    char a;
    int q=-1;
    String x="";
    int t=0;
    for(int i=0;i<=w.length()-1;i++)
    {
        for(int j=0;j<=i;j++)
        {
            t=w.length()-j-1;
            a=w.charAt(t);
            for(int l=w.length()-j-2;l>=w.length()-1-i;l--)
            {
                if(a>w.charAt(l))
                {
                    q=l;
                    break;
                }
            }
            if(q>=0)
            {
                break;
            }
        }
        if(q>=0)
        {
                break;
        }
    }
    x="no answer";
    if(q>=0)
    {
        x=replaceChar(q,t,w);
    }
    return x;
}

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
       

        int T = scanner.nextInt();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");
		
		List qqq=new ArrayList();
        for (int TItr = 0; TItr < T; TItr++) {
            String w = scanner.nextLine();

            String result = biggerIsGreater(w);
			
				qqq.add(result);
           
        }
		for(int i=0;i<=qqq.size()-1;i++)
		{
			System.out.println(qqq.get(i));
		}
        scanner.close();
    }
}
