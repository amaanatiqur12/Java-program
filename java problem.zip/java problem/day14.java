import java.util.*;
public class day14{
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		int y=input.nextInt();
		int a[]=new int[y];
		int b[]=new int[y];
		int c[]=new int[y];
		for(int i=0;i<=y-1;i++)
		{
			a[i]=input.nextInt();
			b[i]=input.nextInt();
			c[i]=input.nextInt();
		}
		int i=0;
		int z=0;
		while(i<=y-1)
		{
			if(a[i]==1&&b[i]==1&&c[i]==0||a[i]==1&&b[i]==0&&c[i]==1||a[i]==0&&b[i]==1&&c[i]==1||a[i]==1&&b[i]==1&&c[i]==1)
			{
				z++;
			}
			i++;
		}
		System.out.println(z);
	}
}