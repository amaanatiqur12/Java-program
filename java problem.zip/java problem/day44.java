import java.util.*;
public class day44{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b[]=new int[a];
		int c[]=new int[a];
		int d=0;
		for(int i=0;i<=a-1;i++)
		{
			b[i]=input.nextInt();
			c[i]=input.nextInt();
			
		}
		
	}
}