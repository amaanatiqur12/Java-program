import java.util.*;
public class day16{
	public static void main(String [] args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		a=a.toLowerCase();
		int b=0;
		String c="";
		char d;
		while(b<=a.length()-1)
			  
		{
			if(a.charAt(b)!='a'&&a.charAt(b)!='e'&&a.charAt(b)!='i'&&a.charAt(b)!='o'&&a.charAt(b)!='u'&&a.charAt(b)!='y')
			{
					c=c+"."+a.charAt(b);
			}
			b++;
		}
		
		System.out.println(c);
	}
}