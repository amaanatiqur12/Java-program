import java.util.*;
public class day49{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b[]=new int[a];
		for(int i=0;i<=a-1;i++)
		{
			b[i]=input.nextInt();
		}
		int o=0,y=0;
		for(int i=0;i<=a-2;i++)
		{
			
			if(b[i+1]-b[i]>=0)
			{
				y++;
				if(y>o)
				{
					o=y;
				}
			}
			else
			{
				y=0;
			}
		}
		System.out.println(o+1);
	}
}