import java.util.*;
public class day88{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String[] a=input.nextLine().split(" ");
		String b=a[0];
		for(int i=1;i<a.length;i++)
		{
			if(b.length()<a[i].length())
				b=a[i];
		}
		System.out.println(b);
	}
}