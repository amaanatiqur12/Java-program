import java.util.*;
public class day104{
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int[] b=new int[a];
		for(int i=0;i<a;i++)
			b[i]=input.nextInt();
		int d=input.nextInt();
		int c=d%a;
		//System.out.println(c);
		int[] g=new int[a];
		int f=0;
		if(c!=0)
		{
			 for(int i=a-d;i<a;i++)
			{
				g[f]=b[i];
				f++;
			}
			for(int i=0;i<a-d;i++)
			{
				g[f]=b[i];
				f++;
			}
			for(int i=0;i<a;i++)
			{
				System.out.println(g[i]);
			}
		}
		else
		{
			for(int i=0;i<a;i++)
			{
				System.out.println(b[i]);
			}
		}
		
	}
}