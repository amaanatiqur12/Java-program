import java.util.*;
public class try{
	public static void main(String [] args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		if(a%2==0)
		{
			System.out.println("YES");
		}
		else
		{
			System.out.println("NO");
		}
	}
}