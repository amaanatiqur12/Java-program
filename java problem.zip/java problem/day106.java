import java.util.*;
public class day106{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=a;
		int flag=0;
		ArrayList c=new ArrayList<>();
		while(b!=1)
		{
			int i;
			for(i=9;i>=2;i--)
			{
				if(b%i==0)
				{
					b=b/i;
					c.add(i);
					//System.out.println(b);
					break;
				}
				//System.out.println(2);	
			}
			if(i==1)
			{
				flag=-1;
				break;
			}	
			//System.out.println(3);
		}
		Collections.sort(c); 
		String[] e=new String[c.size()];
		for(int i=0;i<c.size();i++)
			e[i]=String.valueOf(c.get(i));
		String f=String.join("",e);
		if(flag==-1)
			System.out.println(-1);
		else
			System.out.println(f);
	}
}