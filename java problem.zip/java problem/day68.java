import java.util.*;
public class day68{
	public static void main(String[]args){
		Scanner input =new Scanner(System.in);
		String text=input.next();
		int a,l;
        String c="",m;
       ArrayList<String> o=new ArrayList<>();
		int qq;
		int ww;
       for(int i=0;i<text.length();i++)
       {
           for(int j=2;j<=text.length()-i;j=j+2)
           {
			  qq=0;ww=0;
			 
              c=subString(text,i,i+j);
			 
			  int k=c.length()/2;
			  String r=subString(c,0,k);
			 
			  String s=subString(c,k,c.length());
			  for(int ii=0;ii<=r.length()-1;ii++)
			  {
				  qq=qq+Integer.parseInt(String.valueOf(r.charAt(ii)));
				  ww=ww+Integer.parseInt(String.valueOf(s.charAt(ii)));
			  }
			 // System.out.println(c+"=>"+r+"+"+s);
			  if(qq==ww)
			  {
//				  System.out.println("yes");
				  o.add(c);
			  }
			  
              
           }
       }
	   
       String max="";
       if(o.size()>0)
       {
             max=String.valueOf(o.get(0));
			 
       }
       String normal="";
       for(int i=1;i<o.size();i++)
       {
           normal=o.get(i);
		  // System.out.println(normal);
           if(max.length()<=normal.length())
           {
               max=normal;
           }
       }
       System.out.println(max);
    }

	 public static String subString(String a,int b,int c)
	{
		return a.substring(b,c);
	}	 
}
