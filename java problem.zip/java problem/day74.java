import java.util.*;
public class day74{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();//9
		int b=input.nextInt();//3
		int c=a;// total days 9
		int g=a;// total 9  3 days remainig
		while(g>=b)
		{
			int f = g%b;  //0 
			g=g/b;// 3/3==1
			//System.out.println(g);
			c=c+g;//13
			g=g+f;//1 0
		}
		System.out.println(c)//13
	}
}