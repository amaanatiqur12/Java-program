import java.util.*;
public class day78{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		int b=input.nextInt();
		int ans=0;
		int i=-1;
		int j=-1;
		HashMap<Character,Integer> d=new HashMap();
		while(true)
		{
			char c;
			while(i<a.length()-1)
			{
				i++;
				c=a.charAt(i);
				d.put(c,d.getOrDefault(c,0)+1);
				if(d.size()<=b)
				{
					ans+=i-j;
				}
				else
				{
					break;
				}
			}
			if(i==a.length()-1&&d.size()<=b)
			{
				break;
			}
		
			while(d.size()>b)
			{
				j++;
				c=a.charAt(j);
				if(d.get(c)>1)
				{
					d.put(c,d.get(c)-1);
				}
				else
				{
					d.remove(c);
				}
				if(d.size()<=b)
				{
					ans+=i-j;
					break;
				}
				else
				{
					continue;
				}
			}
		}
		
		System.out.println(ans);
	}
}