import java.util.*;
public class day1{
	public static void main(String[]args)
	{
		int value;
		Scanner input=new Scanner(System.in);
		value=input.nextInt();
		if(value%2==0&&value!=2){
			System.out.println("Yes");
		}
		else
		{
			System.out.println("No");
		}
	}
}