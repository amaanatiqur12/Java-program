import java.util.*;
public class hashmap1{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		HashMap<Character,Integer> char_map=new HashMap();
		for(int i=0;i<a.length();i++)
		{
			char c=a.charAt(i);
			if(char_map.containsKey(c))
			{
				char_map.put(c,char_map.get(c)+1);
			}
			else
			{
				char_map.put(c,1);
			}
		}
		int j=0;
		for(int i=0;i<a.length();i++)
		{
			char c=a.charAt(i);
			if(char_map.get(c)==1)
			{
				j=1;
				System.out.println(c);
			}
		}
		if(j!=1)
		{
			System.out.println("-");
		}
	}
}