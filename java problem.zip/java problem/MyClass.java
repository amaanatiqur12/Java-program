import java.util.*;
public class MyClass{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a =input.nextInt();
		int b=0;
		int c=0;
		int d=0;
		int sum=0;
		do
		{
			c=c+1;
			b=b+3;
		}while(b<a);
		if(b<a)
		{
			b=b+2;
			d=d+1;
		}
		while(b!=a)
		{
			b=b+2-3;
			d=d+1;
			c=c-1;
		}
		if(c!=0)
		{
			sum=(int)Math.pow(3, c);
		}
		if(d!=0)
		{
			sum+=(int)Math.pow(2, d);
		}
		
		
		
		System.out.println(sum);
		
	}
}