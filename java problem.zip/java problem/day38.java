import java.util.*;
public class day38{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.nextLine();
		HashMap<Character, Integer> b=new HashMap<>();
		for(int i=0;i<=a.length()-1;i++)
		{
		 if(b.get(a.charAt(i))!=null)
		  {
				b.put(a.charAt(i),b.get(a.charAt(i))+1);
		  }
		else
		  {
				b.put(a.charAt(i),1);
		  }
		}
		Iterator<Character> d=b.keySet().iterator();
		while(d.hasNext())
		{
			char e=d.next();
			if(b.get(e)>1)
			{
				System.out.println(e+" apear in a sentance "+b.get(e)+" times");
			}
		}
	}
}