import java.util.*;
public class day1{
	public static class Node{
		int data;
		Node next;
	}
	public static class Linklist{
		int size;
		Node tail;
		Node head;
		void addlast(int val){
			Node temp=new Node();
			temp.data=val;
			temp.next=null;
			if(size==0)
				tail=head=temp;
			else
			{
				tail.next=temp;
				tail=temp;
			}
			size++;
		}
		void display()
		{
			Node key=head;
			while(key!=null)
			{
				System.out.println(key.data);
				key=  key.next;
			}
			
		}
		
	}

	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int[] b=new int[a];
		for(int i=0;i<a;i++)
			b[i]=input.nextInt();
		Linklist addlas=new Linklist();
		for(int i=0;i<a;i++)
			addlas.addlast(b[i]);
		addlas.display();
	}
}