import java.util.*;
public class day62{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		String a=input.next();
		String b=a.replaceAll("WUB"," ");
		
		String[] c=b.split("\\s+");
		String line=String.join(" ", c);
		if(line.charAt(0)==' ')
		{
				line=subString(line);
		}
		System.out.println(line);
		
	}
	public static String subString(String line)
	{
		return line.substring(1,line.length());
	}
}