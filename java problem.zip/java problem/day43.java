import java.util.*;
public class day43{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b[]=new int[a];
		for(int i=0;i<=a-1;i++)
		{
			b[i]=input.nextInt();
		}
		int c[]=new int[a-1];
		for(int i=0;i<=a-2;i++)
		{
			c[i]=input.nextInt();
		}
		int d[]=new int[a-2];
		for(int i=0;i<=a-3;i++)
		{
			d[i]=input.nextInt();
		}
		int g=0,k=0,l=0;
		for(int i=0;i<=a-1;i++)
		{
			g=g+b[i];
		}
		for(int i=0;i<=a-2;i++)
		{
			k=k+c[i];
		}
		for(int i=0;i<=a-3;i++)
		{
			l=l+d[i];
		}
		int u=g-k;
		int r=k-l;
		System.out.println(u);
		System.out.println(r);
	}
}