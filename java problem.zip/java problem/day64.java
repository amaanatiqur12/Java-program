import java.util.*;
public class day64{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		int c[]=new int[b];
		for(int i=0;i<b;i++)
		{
			c[i]=input.nextInt();
		}
		int temp;
		
		for(int i=0;i<b;i++)
		{
			int max=c[i];
			int min=i;
			for(int j=i+1;j<b;j++)
			{
				if(max>c[j])
				{
					max=c[j];
					min=j;
				}
			}
			temp=c[i];
			c[i]=max;
			c[min]=temp;
		}
		int min=Integer.MAX_VALUE;
		for(int i=0;i<b-a+1;i++)
		{
			min=Math.min(min,c[i+a-1]-c[i]);
		}
		System.out.println(min);
	}
}