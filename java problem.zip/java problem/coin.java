import java.util.*;
public class coin{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		System.out.print("Enter total money:");
		int j=input.nextInt();
		System.out.print("Enter number of coin:");
		input.nextLine();
		String c=input.nextLine();
		//c=" "+c;
		//System.out.println(c);
		String[] k=c.split(" ");
		//System.out.println(Arrays.toString(k));
		int[] o=new int[k.length];
		for(int i=0;i<k.length;i++)
			o[i]=Integer.parseInt(k[i]);
		/**for(int i=0;i<k.length;i++)
			System.out.println(o[i]);**/
		System.out.println(number_coin(j,o));
	}
	public static int number_coin(int z,int[] o)
	{
		if(z==0) return 0;
		
		
		
		int r=Integer.MAX_VALUE;
		//System.out.println("1");
		for(int u=0;u<o.length;u++)
		{
			if(z-o[u]>=0)
			{
				int total_coin=number_coin(z-o[u],o);
				//System.out.println("1");
				if(total_coin+1<r&&total_coin!=Integer.MAX_VALUE)
				{
					//System.out.println("1");
					r=total_coin+1;
				}
			}
		}
		
		
		
		return r;
	}
}
/**import java.util.*;
public class coin{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		int amount=input.nextInt();
		int coins_total=input.nextInt();
		int coins[]=new int[coins_total];
		for(int i=0;i<=coins_total-1;i++)
		{
			coins[i]=input.nextInt();
		}
		System.out.println(numberOfCoins(amount,coins));
	}
	public static long  numberOfCoins(int amount,int[] coins_total)
	{
		return numberOfCoins(amount,coins_total,0);
	}
	public static long  numberOfCoins(int amount,int[] coins_total,int index)
	{
		if(amount==0)
		{
			return 1;
		}
		if(index>coins_total.length-1)
		{
			return 0;
		}
		long ways=0;
		int value=0;
		while(value<=amount)
		{
			int amount_remaning=amount-value;
			ways+=numberOfCoins(amount_remaning,coins_total,index+1);
			value+=coins_total[index];
		}
		return ways;
	}
}**/