import java.util.*;
public class day50{
	
	
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		long a=input.nextLong();
		int b=input.nextInt();
		long c[]=new long[b];
		for(int i=0;i<=b-1;i++)
		{
			c[i]=input.nextInt();
		}
		long o=0;
		long k=1;
		for(int i=0;i<=b-1;i++)
		{
			while(true)
			{
				if(k==c[i])
				{
					break;
				}
				
				
				if(k<c[i])
				{
					o=o+c[i]-k;
					k=k+c[i]-k;
					
					break;
				}
				if(k>c[i])
				{
					
					o=o+a-k;
					
					o=o+1;
					k=1;
					
				}
				
			}
		}
		System.out.println(o);
	}
}