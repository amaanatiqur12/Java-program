import java.util.*;
public class day99{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		ArrayList<ArrayList<Integer>> a=new ArrayList<ArrayList<Integer>>();
		int k=input.nextInt();
		for(int i=0;i<k;i++)
		{
			String[] b=input.nextLine().split(" ");
			System.out.println(b.length);
			
			for(int j=0;j<b.length-1;j++)
				a.get(i).add(Integer.parseInt(b[j]));
			input.nextLine();
		}
		for(int i=0;i<k;i++)
			System.out.println(Collections.min(a.get(i)));
	}
}