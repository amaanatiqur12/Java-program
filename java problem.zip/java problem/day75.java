import java.util.*;
import java.math.BigInteger;
public class day75{
	public static void main(String[] ars){
		Scanner input=new Scanner(System.in);
		int a=input.nextInt();
		String[] d=new String[a];
		for(int i=0;i<=a-1;i++)
		{
			d[i]=input.next();
		}
		int c=0;
		
		while(c<=a-1)
		{
			 BigInteger f =new BigInteger(d[c]); 
			 
			 BigInteger b2=BigInteger.valueOf(2);
			 BigInteger j= f;//4
			 BigInteger result2=f;
			 int value;
			 do
			 {
				result2 = result2.divide(b2);//6//3
				
				j = result2.remainder(b2);//0//1
				
				value=result2.compareTo(BigInteger.valueOf(2));
				
			 }while(value==1&&j.equals(BigInteger.valueOf(0)));	
			 
			 BigInteger result3 = f.remainder(b2);
			 if(!f.equals(BigInteger.valueOf(2)))
			 {
				 if(!j.equals(BigInteger.valueOf(0))||!result3.equals(BigInteger.valueOf(0)))
				 {
					System.out.println("YES");
				 }
				 else
				 {
					 System.out.println("NO");
				 }
			 }
			 else
			 {
				 System.out.println("NO");
			 }
			 c++;
		}
	}
}